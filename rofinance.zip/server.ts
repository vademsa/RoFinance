import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Initialize Gemini AI client if API key is present
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY chưa được cấu hình trong Secrets!');
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  };

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'RoFinance Server' });
  });

  // Simulated Open Banking Sync API
  app.post('/api/bank/sync', (req, res) => {
    const { bankCode, accountNumber } = req.body;
    
    // Simulate API delay & fresh balance sync
    setTimeout(() => {
      const mockBalances: Record<string, number> = {
        TCB: 15400000 + Math.floor(Math.random() * 200000),
        SEAB: 28500000,
        MB: 5200000,
        MOMO: 1800000 + Math.floor(Math.random() * 50000),
        VCB: 12400000,
      };

      const now = new Date();
      const timeStr = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now
        .getDate()
        .toString()
        .padStart(2, '0')} ${now.getHours().toString().padStart(2, '0')}:${now
        .getMinutes()
        .toString()
        .padStart(2, '0')}`;

      res.json({
        success: true,
        bankCode,
        accountNumber,
        newBalance: mockBalances[bankCode] || 10000000,
        lastSynced: timeStr,
        message: `Đồng bộ tài khoản ${bankCode} - ${accountNumber} thành công!`,
      });
    }, 800);
  });

  // Gemini AI Financial Advisor Route
  app.post('/api/financial-advice', async (req, res) => {
    try {
      const { userQuery, jars, monthlyIncome, recentTransactions } = req.body;

      const ai = getGeminiClient();

      const systemPrompt = `
Bạn là "Trợ lý Tài chính AI" cao cấp dành cho người Việt Nam của ứng dụng RoFinance.
Nhiệm vụ của bạn là đưa ra những phân tích, lời khuyên và chiến lược quản lý tài chính thông minh, thực tế, thân thiện dựa trên mô hình 6 Hũ Tài Chính (Jars System) thích ứng với bối cảnh tài chính cá nhân tại Việt Nam.

Dữ liệu tài chính hiện tại của người dùng:
- Thu nhập hàng tháng: ${monthlyIncome ? monthlyIncome.toLocaleString('vi-VN') + ' VNĐ' : 'Chưa cập nhật'}
- Danh sách 6 Hũ Tài Chính hiện tại:
${JSON.stringify(jars, null, 2)}

- Chi tiết một số giao dịch gần đây:
${JSON.stringify(recentTransactions ? recentTransactions.slice(0, 10) : [], null, 2)}

Nguyên tắc trả lời:
1. Trả lời hoàn toàn bằng tiếng Việt, phân cú pháp rõ ràng, súc tích, dễ hiểu với các biểu tượng cảm xúc (emoji) sinh động.
2. Đưa ra góc nhìn thực tế: nếu hũ nào đang vượt quá ngân sách (đặc biệt Hưởng thụ PLAY hoặc Trả nợ DEBT), hãy cảnh báo và gợi ý cách cắt giảm hoặc tái phân bổ hũ.
3. Đề xuất chiến lược tối ưu hóa dòng tiền, tiết kiệm và đầu tư phù hợp cho người Việt.
4. Giữ thái độ động viên, tích cực và tôn trọng privacy người dùng.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: userQuery || 'Hãy phân tích tình hình tài chính hiện tại của tôi và đưa ra 3 lời khuyên tối ưu nhất cho tháng này.',
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.7,
        },
      });

      res.json({
        success: true,
        reply: response.text,
      });
    } catch (error: any) {
      console.error('Gemini API error:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Không thể kết nối tới Trợ lý AI Gemini',
      });
    }
  });

  // Vite development middleware vs production static files
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server RoFinance running on http://localhost:${PORT}`);
  });
}

startServer();
