export type BankCode = 'TCB' | 'SEAB' | 'MB' | 'MOMO' | 'VCB' | 'VPB' | 'ACB' | 'BIDV' | 'CTG';

export interface Jar {
  id: string;
  code: 'NEC' | 'FFA' | 'PLAY' | 'GIVE' | 'EDU' | 'DEBT' | string;
  name: string;
  percentage: number; // e.g. 40, 9.30, 9.45, 5, 10, 26.25
  bankName: string;
  bankCode: BankCode;
  accountNumber: string;
  accountName: string;
  color: string;
  description: string;
  targetBudget: number; // Calculated based on income or user override
  currentSpent: number;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense' | 'transfer';
  amount: number;
  jarId: string;
  category: string;
  date: string; // ISO format or YYYY-MM-DD
  description: string;
  bankName?: string;
  recipientAccount?: string;
  recipientBank?: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  bankCode: BankCode;
  accountNumber: string;
  accountHolder: string;
  balance: number;
  lastSynced: string;
  status: 'connected' | 'disconnected' | 'syncing';
  logoUrl?: string;
  linkedJarCode?: string;
}

export interface MonthlyIncomeRecord {
  id: string;
  monthYear: string; // e.g. "2026-07"
  incomeAmount: number;
  allocations: {
    jarId: string;
    allocatedAmount: number;
    percentage: number;
    isTransferred: boolean;
  }[];
  createdAt: string;
}

export interface AlertNotification {
  id: string;
  jarId: string;
  jarName: string;
  level: 'warning' | 'danger'; // warning: >=80%, danger: >=100%
  spentPercentage: number;
  message: string;
  date: string;
}

export interface CryptoAsset {
  id: string;
  symbol: string; // e.g. 'BTC', 'ETH', 'SOL', 'BNB'
  name: string; // e.g. 'Bitcoin', 'Ethereum'
  amountHeld: number; // e.g. 0.15
  buyPriceUSD: number; // Entry price in USD
  buyDate?: string;
  notes?: string;
  linkedJarCode?: string; // e.g. 'FFA'
}

export interface BinanceTicker {
  symbol: string; // e.g. 'BTCUSDT'
  lastPrice: string; // '64200.50'
  priceChange: string;
  priceChangePercent: string; // '2.45'
  highPrice: string;
  lowPrice: string;
  volume: string;
  quoteVolume: string;
}

export interface DebtItem {
  id: string;
  name: string; // e.g. "Vay mua xe", "Trả góp điện thoại"
  totalAmount: number; // e.g. 60,000,000
  remainingAmount: number; // e.g. 30,000,000
  startMonth: string; // e.g. "2026-01"
  endMonth: string; // e.g. "2026-12"
  monthlyPayment: number; // e.g. 5,000,000
  status: 'active' | 'paid';
  notes?: string;
  reallocateTargetCode?: 'FFA' | 'PROPORTIONAL' | string;
}


