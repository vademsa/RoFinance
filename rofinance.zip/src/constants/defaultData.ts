import { Jar, BankAccount, Transaction, BankCode, DebtItem } from '../types';

export const DEFAULT_MONTHLY_INCOME = 20000000; // 20,000,000 VND default example

export const DEFAULT_JARS: Jar[] = [
  {
    id: 'jar-nec',
    code: 'NEC',
    name: 'Nhu cầu thiết yếu',
    percentage: 40.0,
    bankName: 'Techcombank',
    bankCode: 'TCB',
    accountNumber: '190368889999',
    accountName: 'NGUYEN VAN A',
    color: '#3B82F6', // Blue
    description: 'Ăn uống, thuê nhà, điện nước, xăng xe, hóa đơn sinh hoạt',
    targetBudget: 8000000, // 40% of 20M
    currentSpent: 5420000,
  },
  {
    id: 'jar-ffa',
    code: 'FFA',
    name: 'Tự do tài chính',
    percentage: 9.30,
    bankName: 'SeaBank',
    bankCode: 'SEAB',
    accountNumber: '000088992211',
    accountName: 'NGUYEN VAN A',
    color: '#10B981', // Emerald
    description: 'Đầu tư cổ phiếu, tiết kiệm dài hạn, tạo dòng tiền bị động',
    targetBudget: 1860000, // 9.3% of 20M
    currentSpent: 0,
  },
  {
    id: 'jar-play',
    code: 'PLAY',
    name: 'Hưởng thụ',
    percentage: 9.45,
    bankName: 'MBBank',
    bankCode: 'MB',
    accountNumber: '999966668888',
    accountName: 'NGUYEN VAN A',
    color: '#F59E0B', // Amber
    description: 'Du lịch, mua sắm đồ cá nhân, giải trí, đi cafe, thư giãn',
    targetBudget: 1890000, // 9.45% of 20M
    currentSpent: 1650000, // High usage to trigger warning (>80%)
  },
  {
    id: 'jar-give',
    code: 'GIVE',
    name: 'Cho đi',
    percentage: 5.0,
    bankName: 'Ví MoMo',
    bankCode: 'MOMO',
    accountNumber: '0987654321',
    accountName: 'NGUYEN VAN A',
    color: '#EC4899', // Pink
    description: 'Quà biếu cha mẹ, từ thiện, giúp đỡ bạn bè, đám xá',
    targetBudget: 1000000, // 5% of 20M
    currentSpent: 450000,
  },
  {
    id: 'jar-edu',
    code: 'EDU',
    name: 'Giáo dục',
    percentage: 10.0,
    bankName: 'Vietcombank',
    bankCode: 'VCB',
    accountNumber: '0071001234567',
    accountName: 'NGUYEN VAN A',
    color: '#8B5CF6', // Purple
    description: 'Mua sách, khóa học online, hội thảo, nâng cao kỹ năng',
    targetBudget: 2000000, // 10% of 20M
    currentSpent: 1200000,
  },
  {
    id: 'jar-debt',
    code: 'DEBT',
    name: 'Trả nợ',
    percentage: 26.25,
    bankName: 'Vietcombank',
    bankCode: 'VCB',
    accountNumber: '0071009876543',
    accountName: 'NGUYEN VAN A',
    color: '#EF4444', // Red
    description: 'Thanh toán khoản vay mua nhà/xe, trả thẻ tín dụng hàng tháng',
    targetBudget: 5250000, // 26.25% of 20M
    currentSpent: 5300000, // >100% usage to trigger danger alert
  },
];

export const DEFAULT_BANK_ACCOUNTS: BankAccount[] = [
  {
    id: 'bank-tcb',
    bankName: 'Techcombank (TCB)',
    bankCode: 'TCB',
    accountNumber: '190368889999',
    accountHolder: 'NGUYEN VAN A',
    balance: 14850000,
    lastSynced: '2026-07-28 08:30',
    status: 'connected',
    linkedJarCode: 'NEC',
  },
  {
    id: 'bank-seab',
    bankName: 'SeaBank',
    bankCode: 'SEAB',
    accountNumber: '000088992211',
    accountHolder: 'NGUYEN VAN A',
    balance: 28500000,
    lastSynced: '2026-07-28 08:30',
    status: 'connected',
    linkedJarCode: 'FFA',
  },
  {
    id: 'bank-mb',
    bankName: 'MBBank',
    bankCode: 'MB',
    accountNumber: '999966668888',
    accountHolder: 'NGUYEN VAN A',
    balance: 5200000,
    lastSynced: '2026-07-28 08:30',
    status: 'connected',
    linkedJarCode: 'PLAY',
  },
  {
    id: 'bank-momo',
    bankName: 'Ví MoMo',
    bankCode: 'MOMO',
    accountNumber: '0987654321',
    accountHolder: 'NGUYEN VAN A',
    balance: 1800000,
    lastSynced: '2026-07-28 08:30',
    status: 'connected',
    linkedJarCode: 'GIVE',
  },
  {
    id: 'bank-vcb',
    bankName: 'Vietcombank (VCB)',
    bankCode: 'VCB',
    accountNumber: '0071001234567',
    accountHolder: 'NGUYEN VAN A',
    balance: 12400000,
    lastSynced: '2026-07-28 08:30',
    status: 'connected',
    linkedJarCode: 'EDU',
  },
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-101',
    type: 'income',
    amount: 20000000,
    jarId: 'jar-nec',
    category: 'Lương hàng tháng',
    date: '2026-07-01',
    description: 'Lương công ty chuyển khoản tháng 7',
    bankName: 'Techcombank',
  },
  {
    id: 'tx-102',
    type: 'expense',
    amount: 3500000,
    jarId: 'jar-nec',
    category: 'Tiền thuê nhà',
    date: '2026-07-03',
    description: 'Chuyển tiền thuê nhà tháng 7',
    bankName: 'Techcombank',
  },
  {
    id: 'tx-103',
    type: 'expense',
    amount: 1200000,
    jarId: 'jar-nec',
    category: 'Điện nước & Internet',
    date: '2026-07-05',
    description: 'Thanh toán hóa đơn điện nước gia đình',
    bankName: 'Techcombank',
  },
  {
    id: 'tx-104',
    type: 'expense',
    amount: 720000,
    jarId: 'jar-nec',
    category: 'Đi chợ & Siêu thị',
    date: '2026-07-10',
    description: 'Mua thực phẩm sinh hoạt tuần 2',
    bankName: 'Techcombank',
  },
  {
    id: 'tx-105',
    type: 'expense',
    amount: 1200000,
    jarId: 'jar-edu',
    category: 'Khóa học online',
    date: '2026-07-08',
    description: 'Đăng ký khóa học Quản trị Tài chính AI',
    bankName: 'Vietcombank',
  },
  {
    id: 'tx-106',
    type: 'expense',
    amount: 1650000,
    jarId: 'jar-play',
    category: 'Ăn uống & Giải trí',
    date: '2026-07-15',
    description: 'Tụ tập ăn uống cuối tuần cùng đồng nghiệp',
    bankName: 'MBBank',
  },
  {
    id: 'tx-107',
    type: 'expense',
    amount: 450000,
    jarId: 'jar-give',
    category: 'Quà biếu',
    date: '2026-07-18',
    description: 'Mua hoa quả biếu gia đình',
    bankName: 'Ví MoMo',
  },
  {
    id: 'tx-108',
    type: 'expense',
    amount: 5300000,
    jarId: 'jar-debt',
    category: 'Trả nợ vay',
    date: '2026-07-20',
    description: 'Trích nợ tự động ngân hàng Vietcombank',
    bankName: 'Vietcombank',
  },
];

export const CATEGORIES_BY_JAR_CODE: Record<string, string[]> = {
  NEC: ['Tiền thuê nhà', 'Điện nước & Internet', 'Đi chợ & Siêu thị', 'Xăng xe & Bãi đỗ', 'Hóa đơn sinh hoạt', 'Khác'],
  FFA: ['Cổ phiếu & Chứng khoán', 'Gửi tiết kiệm', 'Vàng & Bất động sản', 'Quỹ chỉ số', 'Khác'],
  PLAY: ['Ăn uống & Giải trí', 'Du lịch & Nghỉ dưỡng', 'Mua sắm thời trang', 'Phim ảnh & Game', 'Spa & Chăm sóc', 'Khác'],
  GIVE: ['Quà biếu gia đình', 'Mừng cưới / Sinh nhật', 'Từ thiện & Quyên góp', 'Giúp đỡ bạn bè', 'Khác'],
  EDU: ['Khóa học online', 'Sách & Tạp chí', 'Hội thảo & Workshop', 'Dụng cụ học tập', 'Khác'],
  DEBT: ['Trả nợ ngân hàng', 'Thanh toán thẻ tín dụng', 'Trả nợ người thân', 'Khác'],
};

export const BANK_OPTIONS: { code: BankCode; name: string; shortName: string }[] = [
  { code: 'TCB', name: 'Techcombank (Ngân hàng Kỹ Thương)', shortName: 'Techcombank' },
  { code: 'SEAB', name: 'SeaBank (Ngân hàng Đông Nam Á)', shortName: 'SeaBank' },
  { code: 'MB', name: 'MBBank (Ngân hàng Quân Đội)', shortName: 'MBBank' },
  { code: 'MOMO', name: 'Ví điện tử MoMo', shortName: 'Ví MoMo' },
  { code: 'VCB', name: 'Vietcombank (Ngân hàng Ngoại Thương)', shortName: 'Vietcombank' },
  { code: 'VPB', name: 'VPBank (Ngân hàng Thịnh Vượng)', shortName: 'VPBank' },
  { code: 'ACB', name: 'ACB (Ngân hàng Á Châu)', shortName: 'ACB' },
  { code: 'BIDV', name: 'BIDV (Ngân hàng ĐT&PT Việt Nam)', shortName: 'BIDV' },
  { code: 'CTG', name: 'VietinBank (Ngân hàng Công Thương)', shortName: 'VietinBank' },
];

export const DEFAULT_USD_VND_RATE = 25450; // Standard USD to VND exchange rate

export const POPULAR_BINANCE_SYMBOLS = [
  { symbol: 'BTCUSDT', coin: 'BTC', name: 'Bitcoin' },
  { symbol: 'ETHUSDT', coin: 'ETH', name: 'Ethereum' },
  { symbol: 'BNBUSDT', coin: 'BNB', name: 'BNB' },
  { symbol: 'SOLUSDT', coin: 'SOL', name: 'Solana' },
  { symbol: 'XRPUSDT', coin: 'XRP', name: 'Ripple' },
  { symbol: 'DOGEUSDT', coin: 'DOGE', name: 'Dogecoin' },
  { symbol: 'ADAUSDT', coin: 'ADA', name: 'Cardano' },
  { symbol: 'AVAXUSDT', coin: 'AVAX', name: 'Avalanche' },
  { symbol: 'NEARUSDT', coin: 'NEAR', name: 'NEAR Protocol' },
  { symbol: 'DOTUSDT', coin: 'DOT', name: 'Polkadot' },
  { symbol: 'LINKUSDT', coin: 'LINK', name: 'Chainlink' },
  { symbol: 'SUIUSDT', coin: 'SUI', name: 'Sui' },
  { symbol: 'PEPEUSDT', coin: 'PEPE', name: 'Pepe' },
];

export const DEFAULT_CRYPTO_ASSETS = [
  {
    id: 'crypto-1',
    symbol: 'BTC',
    name: 'Bitcoin',
    amountHeld: 0.15,
    buyPriceUSD: 62000,
    buyDate: '2026-03-15',
    notes: 'Tích lũy từ hũ Tự Do Tài Chính (FFA)',
    linkedJarCode: 'FFA',
  },
  {
    id: 'crypto-2',
    symbol: 'ETH',
    name: 'Ethereum',
    amountHeld: 1.5,
    buyPriceUSD: 3100,
    buyDate: '2026-04-10',
    notes: 'Đầu tư staking dài hạn',
    linkedJarCode: 'FFA',
  },
  {
    id: 'crypto-3',
    symbol: 'SOL',
    name: 'Solana',
    amountHeld: 12.0,
    buyPriceUSD: 135,
    buyDate: '2026-05-20',
    notes: 'Hệ sinh thái Solana DeFi',
    linkedJarCode: 'FFA',
  },
];

export const DEFAULT_DEBT_ITEMS: DebtItem[] = [
  {
    id: 'debt-1',
    name: 'Vay tín dụng Vietcombank mua xe',
    totalAmount: 63000000,
    remainingAmount: 31500000,
    startMonth: '2026-01',
    endMonth: '2026-12',
    monthlyPayment: 5250000, // 26.25% of 20M
    status: 'active',
    notes: 'Trích nợ tự động hàng tháng ngày 20 qua VCB',
    reallocateTargetCode: 'FFA',
  },
];


