import React from 'react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  AreaChart,
  Area,
} from 'recharts';
import { Jar, Transaction } from '../types';
import { formatVND, formatShortVND } from '../utils/formatters';
import { PieChart as PieIcon, TrendingUp, BarChart3, Wallet } from 'lucide-react';

interface AnalyticsChartsProps {
  jars: Jar[];
  transactions: Transaction[];
  monthlyIncome: number;
  isAmountsHidden?: boolean;
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({
  jars,
  transactions,
  monthlyIncome,
  isAmountsHidden = false,
}) => {

  // Data for Jar Allocation vs Spent Donut/Pie Chart
  const jarAllocationData = jars.map((j) => ({
    name: j.name,
    code: j.code,
    budget: j.targetBudget,
    spent: j.currentSpent,
    color: j.color,
  }));

  // Data for Category breakdown
  const categoryMap: Record<string, number> = {};
  transactions
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      categoryMap[t.category] = (categoryMap[t.category] || 0) + t.amount;
    });

  const categoryData = Object.entries(categoryMap).map(([category, amount]) => ({
    category,
    amount,
  }));

  // Historical Cashflow Mock Data
  const monthlyCashflowData = [
    { month: 'T3/2026', income: 18000000, expense: 14200000 },
    { month: 'T4/2026', income: 18000000, expense: 15100000 },
    { month: 'T5/2026', income: 20000000, expense: 16200000 },
    { month: 'T6/2026', income: 20000000, expense: 13800000 },
    { month: 'T7/2026', income: monthlyIncome, expense: jars.reduce((s, j) => s + j.currentSpent, 0) },
  ];

  return (
    <div className="space-y-8 text-zinc-100">
      {/* Title */}
      <div className="bg-[#121214] p-6 rounded-[28px] border border-zinc-800 shadow-xl flex items-center justify-between">
        <div>
          <h2 className="text-xl font-black text-white tracking-tight flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-indigo-400" />
            <span>Biểu Đồ Thống Kê & Dòng Tiền Bento</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Trực quan hóa tỷ lệ phân bổ 6 hũ và xu hướng thu chi thực tế theo thời gian
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Jar Allocation vs Actual Spent Donut Chart */}
        <div className="bg-[#121214] p-6 rounded-[28px] border border-zinc-800 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-extrabold text-white flex items-center space-x-2">
              <PieIcon className="w-4 h-4 text-indigo-400" />
              <span>Tỷ Lệ Phân Bổ Hũ Ngân Sách</span>
            </h3>
            <span className="text-xs text-zinc-500 font-mono">Đơn vị: VNĐ</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={jarAllocationData}
                  dataKey="budget"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={3}
                >
                  {jarAllocationData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number) => [formatVND(value, isAmountsHidden), 'Hạn mức']}
                  contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Legend Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-4 pt-4 border-t border-zinc-800 text-xs">
            {jars.map((j) => (
              <div key={j.id} className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full shrink-0 shadow-sm" style={{ backgroundColor: j.color }} />
                <span className="font-bold text-zinc-200 truncate">{j.code}</span>
                <span className="text-zinc-500">({j.percentage}%)</span>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Monthly Income vs Expense Area Chart */}
        <div className="bg-[#121214] p-6 rounded-[28px] border border-zinc-800 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-extrabold text-white flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>Biến Động Thu Nhập vs Chi Tiêu (5 Tháng)</span>
            </h3>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyCashflowData}>
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0.05} />
                  </linearGradient>
                  <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#a1a1aa' }} />
                <YAxis tickFormatter={(v) => formatShortVND(v, isAmountsHidden)} tick={{ fontSize: 10, fill: '#a1a1aa' }} />
                <Tooltip
                  formatter={(val: number) => [formatVND(val, isAmountsHidden), '']}
                  contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                />

                <Legend wrapperStyle={{ color: '#a1a1aa' }} />
                <Area
                  type="monotone"
                  dataKey="income"
                  name="Thu Nhập"
                  stroke="#10B981"
                  fillOpacity={1}
                  fill="url(#colorIncome)"
                />
                <Area
                  type="monotone"
                  dataKey="expense"
                  name="Chi Tiêu"
                  stroke="#EF4444"
                  fillOpacity={1}
                  fill="url(#colorExpense)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* 3. Category Spending Breakdown Bar Chart */}
      <div className="bg-[#121214] p-6 rounded-[28px] border border-zinc-800 shadow-xl">
        <h3 className="text-sm font-extrabold text-white mb-4 flex items-center space-x-2">
          <BarChart3 className="w-4 h-4 text-indigo-400" />
          <span>Cơ Cấu Chi Tiêu Thực Tế Theo Danh Mục</span>
        </h3>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categoryData}>
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#a1a1aa' }} />
              <YAxis tickFormatter={(v) => formatShortVND(v)} tick={{ fontSize: 10, fill: '#a1a1aa' }} />
              <Tooltip
                formatter={(val: number) => [formatVND(val), 'Tổng chi']}
                contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="amount" name="Số tiền" fill="#6366F1" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
