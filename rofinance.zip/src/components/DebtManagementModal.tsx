import React, { useState } from 'react';
import {
  X,
  CreditCard,
  Plus,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Trash2,
  Check,
  RefreshCw,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { DebtItem, Jar } from '../types';
import { formatVND } from '../utils/formatters';
import { calculateMonthsCount, computeMonthlyPayment, recalculateJarsWithDebt } from '../utils/debtCalculator';

interface DebtManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  debtItems: DebtItem[];
  jars: Jar[];
  monthlyIncome: number;
  onUpdateDebts: (newDebts: DebtItem[]) => void;
  onApplyNewJarAllocations: (updatedJars: Jar[]) => void;
  isAmountsHidden?: boolean;
}

export const DebtManagementModal: React.FC<DebtManagementModalProps> = ({
  isOpen,
  onClose,
  debtItems,
  jars,
  monthlyIncome,
  onUpdateDebts,
  onApplyNewJarAllocations,
  isAmountsHidden = false,
}) => {
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [reallocateStrategy, setReallocateStrategy] = useState<'FFA' | 'PROPORTIONAL'>('FFA');

  // Form states
  const [debtName, setDebtName] = useState('');
  const [totalAmount, setTotalAmount] = useState<number | ''>('');
  const [startMonth, setStartMonth] = useState('2026-01');
  const [endMonth, setEndMonth] = useState('2026-12');
  const [monthlyPaymentOverride, setMonthlyPaymentOverride] = useState<number | ''>('');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const monthsCount = calculateMonthsCount(startMonth, endMonth);
  const calculatedMonthlyPayment =
    totalAmount && typeof totalAmount === 'number'
      ? computeMonthlyPayment(totalAmount, startMonth, endMonth)
      : 0;

  const actualMonthlyPayment =
    monthlyPaymentOverride !== '' && typeof monthlyPaymentOverride === 'number'
      ? monthlyPaymentOverride
      : calculatedMonthlyPayment;

  // Active debts calculations
  const activeDebts = debtItems.filter((d) => d.status === 'active' && d.remainingAmount > 0);
  const totalActiveMonthlyPayment = activeDebts.reduce((sum, d) => sum + d.monthlyPayment, 0);
  const totalActiveRemainingAmount = activeDebts.reduce((sum, d) => sum + d.remainingAmount, 0);

  const computedDebtJarPercent =
    monthlyIncome > 0
      ? Number(((totalActiveMonthlyPayment / monthlyIncome) * 100).toFixed(2))
      : 0;

  const handleAddDebt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!debtName.trim() || !totalAmount || Number(totalAmount) <= 0) return;

    const newDebt: DebtItem = {
      id: 'debt-' + Date.now(),
      name: debtName.trim(),
      totalAmount: Number(totalAmount),
      remainingAmount: Number(totalAmount),
      startMonth: startMonth || '2026-01',
      endMonth: endMonth || '2026-12',
      monthlyPayment: actualMonthlyPayment,
      status: 'active',
      notes: notes.trim(),
    };

    const updatedDebts = [...debtItems, newDebt];
    onUpdateDebts(updatedDebts);

    // Auto recalculate jars with the new debt list
    const updatedJars = recalculateJarsWithDebt(
      jars,
      updatedDebts,
      monthlyIncome,
      reallocateStrategy
    );
    onApplyNewJarAllocations(updatedJars);

    // Reset form
    setDebtName('');
    setTotalAmount('');
    setMonthlyPaymentOverride('');
    setNotes('');
    setIsAddingNew(false);
  };

  const handleToggleStatus = (debtId: string) => {
    const updatedDebts = debtItems.map((d) => {
      if (d.id === debtId) {
        const nextStatus = d.status === 'active' ? ('paid' as const) : ('active' as const);
        return {
          ...d,
          status: nextStatus,
          remainingAmount: nextStatus === 'paid' ? 0 : d.totalAmount,
        };
      }
      return d;
    });

    onUpdateDebts(updatedDebts);

    // Auto recalculate jars with the updated status
    const updatedJars = recalculateJarsWithDebt(
      jars,
      updatedDebts,
      monthlyIncome,
      reallocateStrategy
    );
    onApplyNewJarAllocations(updatedJars);
  };

  const handleDeleteDebt = (debtId: string) => {
    const updatedDebts = debtItems.filter((d) => d.id !== debtId);
    onUpdateDebts(updatedDebts);

    const updatedJars = recalculateJarsWithDebt(
      jars,
      updatedDebts,
      monthlyIncome,
      reallocateStrategy
    );
    onApplyNewJarAllocations(updatedJars);
  };

  const handleTriggerAutoRecalculate = () => {
    const updatedJars = recalculateJarsWithDebt(
      jars,
      debtItems,
      monthlyIncome,
      reallocateStrategy
    );
    onApplyNewJarAllocations(updatedJars);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-[#18181b] rounded-[32px] shadow-2xl max-w-4xl w-full overflow-hidden border border-zinc-800 my-8 text-zinc-100">
        {/* Header */}
        <div className="bg-[#121214] text-white p-6 relative border-b border-zinc-800">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-zinc-400 hover:text-white p-1.5 rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-rose-500/10 rounded-2xl border border-rose-500/20 text-rose-400">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-black text-white tracking-tight">
                  Tự Động Tính % Hũ Trả Nợ (DEBT) & Tái Phân Bổ
                </h2>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  Smart Auto-Reallocate
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Nhập danh sách khoản nợ và thời gian trả. Ứng dụng sẽ tự tính % Hũ DEBT hàng tháng và tự động tái phân bổ % sang các hũ khác khi trả xong nợ!
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Smart Calculation Bento Summary Card */}
          <div className="bg-[#121214] border border-zinc-800 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Tổng Hạn Mức Trả Nợ Hàng Tháng</span>
                </div>
                <div className="text-2xl font-black font-mono text-rose-400 mt-1">
                  {formatVND(totalActiveMonthlyPayment, isAmountsHidden)}{' '}
                  <span className="text-xs font-sans font-normal text-zinc-400">
                    / tháng ({computedDebtJarPercent}% thu nhập)
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={handleTriggerAutoRecalculate}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/20 transition-all flex items-center space-x-1.5"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Cập Nhật Tỷ Lệ % Tất Cả Hũ</span>
                </button>
              </div>
            </div>

            {/* Sub stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-zinc-800/80 text-xs">
              <div className="bg-[#1c1c20] p-3 rounded-xl border border-zinc-800">
                <div className="text-[10px] text-zinc-400 font-bold uppercase">Tổng dư nợ còn lại</div>
                <div className="text-sm font-black font-mono text-white mt-0.5">
                  {formatVND(totalActiveRemainingAmount, isAmountsHidden)}
                </div>
              </div>

              <div className="bg-[#1c1c20] p-3 rounded-xl border border-zinc-800">
                <div className="text-[10px] text-zinc-400 font-bold uppercase">Tỷ lệ Hũ DEBT tự động</div>
                <div className="text-sm font-black font-mono text-indigo-400 mt-0.5">
                  {computedDebtJarPercent}% thu nhập
                </div>
              </div>

              <div className="bg-[#1c1c20] p-3 rounded-xl border border-zinc-800">
                <div className="text-[10px] text-zinc-400 font-bold uppercase">Khoản nợ đang trả</div>
                <div className="text-sm font-black text-emerald-400 mt-0.5">
                  {activeDebts.length} khoản nợ hoạt động
                </div>
              </div>
            </div>

            {/* Reallocation Strategy Selector */}
            <div className="pt-2">
              <label className="block text-[11px] font-bold text-zinc-300 uppercase tracking-wider mb-2">
                Chiến lược tự động tái phân bổ khi trả hết nợ:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setReallocateStrategy('FFA')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    reallocateStrategy === 'FFA'
                      ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                      : 'bg-[#1c1c20] border-zinc-800 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 font-bold text-xs text-white">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    <span>Dồn % hết vào Hũ Tự Do Tài Chính (FFA)</span>
                  </div>
                  <p className="text-[11px] text-zinc-400 mt-1">
                    Khi trả xong nợ, số % dư được chuyển toàn bộ sang đầu tư & tự do tài chính.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setReallocateStrategy('PROPORTIONAL')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    reallocateStrategy === 'PROPORTIONAL'
                      ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                      : 'bg-[#1c1c20] border-zinc-800 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 font-bold text-xs text-white">
                    <Zap className="w-4 h-4 text-indigo-400" />
                    <span>Tự phân bổ đều theo tỷ lệ các hũ còn lại</span>
                  </div>
                  <p className="text-[11px] text-zinc-400 mt-1">
                    Chia đều phần % nợ giảm cho 5 hũ (NEC, FFA, PLAY, GIVE, EDU) theo tỷ lệ tiêu chuẩn.
                  </p>
                </button>
              </div>
            </div>
          </div>

          {/* Add New Debt Toggle Button */}
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center space-x-2">
              <CreditCard className="w-4 h-4 text-rose-400" />
              <span>Danh Sách Các Khoản Nợ</span>
            </h3>
            <button
              onClick={() => setIsAddingNew(!isAddingNew)}
              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl transition-all flex items-center space-x-1"
            >
              <Plus className="w-4 h-4" />
              <span>{isAddingNew ? 'Đóng form' : 'Thêm khoản nợ mới'}</span>
            </button>
          </div>

          {/* Add New Debt Form */}
          {isAddingNew && (
            <form
              onSubmit={handleAddDebt}
              className="bg-[#121214] p-5 rounded-2xl border border-rose-500/30 space-y-4 animate-in fade-in"
            >
              <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center space-x-1.5">
                <Plus className="w-4 h-4" />
                <span>Khai Báo Khoản Nợ Mới</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="space-y-1">
                  <label className="font-bold text-zinc-300">Tên khoản nợ</label>
                  <input
                    type="text"
                    placeholder="VD: Trả góp xe máy, Vay mua nhà"
                    value={debtName}
                    onChange={(e) => setDebtName(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-zinc-300">Tổng số tiền nợ (VNĐ)</label>
                  <input
                    type="number"
                    placeholder="VD: 60000000"
                    value={totalAmount}
                    onChange={(e) =>
                      setTotalAmount(e.target.value ? Number(e.target.value) : '')
                    }
                    required
                    className="w-full px-3.5 py-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl text-white font-mono focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-zinc-300">Tháng bắt đầu trả</label>
                  <input
                    type="month"
                    value={startMonth}
                    onChange={(e) => setStartMonth(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-zinc-300">Tháng kết thúc (kết thúc nợ)</label>
                  <input
                    type="month"
                    value={endMonth}
                    onChange={(e) => setEndMonth(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Calculated payment preview */}
              <div className="bg-[#1c1c20] p-3 rounded-xl border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2">
                <div className="text-zinc-400">
                  Thời gian vay: <span className="text-white font-bold">{monthsCount} tháng</span> ({startMonth} đến {endMonth})
                </div>
                <div className="text-rose-300 font-bold">
                  Số tiền tự tính trả mỗi tháng: <span className="font-mono text-white text-sm font-black">{formatVND(calculatedMonthlyPayment)}</span>
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <label className="font-bold text-zinc-300">Ghi chú thêm (không bắt buộc)</label>
                <input
                  type="text"
                  placeholder="VD: Trích nợ tự động ngân hàng VCB ngày 20"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingNew(false)}
                  className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold text-xs rounded-xl transition-colors"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-rose-600/20 flex items-center space-x-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Lưu Khoản Nợ Mới</span>
                </button>
              </div>
            </form>
          )}

          {/* Debt List */}
          <div className="space-y-3">
            {debtItems.length === 0 ? (
              <div className="bg-[#121214] p-8 rounded-2xl border border-zinc-800 text-center text-zinc-400 space-y-2">
                <ShieldCheck className="w-10 h-10 mx-auto text-emerald-400" />
                <h4 className="font-bold text-white text-sm">Hiện Không Có Khoản Nợ Nào</h4>
                <p className="text-xs max-w-sm mx-auto">
                  Tất cả các khoản nợ đã được trả sạch! Hũ DEBT tự động giảm về 0% và toàn bộ số tiền thu nhập được chuyển sang đầu tư & tích lũy.
                </p>
              </div>
            ) : (
              debtItems.map((debt) => {
                const isPaid = debt.status === 'paid' || debt.remainingAmount <= 0;
                const months = calculateMonthsCount(debt.startMonth, debt.endMonth);

                return (
                  <div
                    key={debt.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      isPaid
                        ? 'bg-[#121214]/60 border-zinc-800/80 opacity-75'
                        : 'bg-[#121214] border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span
                            className={`w-2.5 h-2.5 rounded-full ${
                              isPaid ? 'bg-emerald-500' : 'bg-rose-500 animate-pulse'
                            }`}
                          />
                          <h4 className="font-bold text-sm text-white">{debt.name}</h4>
                          <span
                            className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${
                              isPaid
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                            }`}
                          >
                            {isPaid ? 'Đã Trả Hết ✓' : 'Đang Trả Nợ'}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-400">
                          <span className="flex items-center space-x-1">
                            <Calendar className="w-3.5 h-3.5 text-zinc-500" />
                            <span>
                              {debt.startMonth} đến {debt.endMonth} ({months} tháng)
                            </span>
                          </span>
                          {debt.notes && <span>• {debt.notes}</span>}
                        </div>
                      </div>

                      {/* Right side stats & action */}
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <div className="text-[10px] font-bold text-zinc-400 uppercase">
                            Trả Mỗi Tháng
                          </div>
                          <div className="text-sm font-black font-mono text-rose-300">
                            {formatVND(debt.monthlyPayment, isAmountsHidden)}
                          </div>
                          <div className="text-[10px] text-zinc-500 font-mono">
                            Tổng nợ: {formatVND(debt.totalAmount, isAmountsHidden)}
                          </div>
                        </div>

                        <div className="flex items-center space-x-1.5">
                          <button
                            onClick={() => handleToggleStatus(debt.id)}
                            title={isPaid ? 'Đánh dấu chưa trả hết' : 'Đánh dấu đã hoàn thành'}
                            className={`p-2 rounded-xl border text-xs font-bold transition-all ${
                              isPaid
                                ? 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-white'
                                : 'bg-emerald-600/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-600/20'
                            }`}
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteDebt(debt.id)}
                            title="Xóa khoản nợ"
                            className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 transition-all"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#121214] p-5 border-t border-zinc-800 flex items-center justify-between">
          <div className="text-xs text-zinc-400 flex items-center space-x-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Tự động đồng bộ với Firestore Database</span>
          </div>

          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-all shadow-lg shadow-indigo-600/20"
          >
            Đóng & Áp Dụng
          </button>
        </div>
      </div>
    </div>
  );
};
