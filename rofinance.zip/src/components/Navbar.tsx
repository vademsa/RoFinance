import React from 'react';
import {
  Wallet,
  PlusCircle,
  QrCode,
  Landmark,
  Bot,
  FileSpreadsheet,
  Printer,
  Sparkles,
  PieChart,
  Coins,
  Eye,
  EyeOff,
  ShieldCheck,
} from 'lucide-react';

interface NavbarProps {
  monthlyIncome: number;
  totalSpent: number;
  totalAllocated: number;
  onOpenIncomeModal: () => void;
  onOpenTransactionModal: () => void;
  onOpenBankSyncModal: () => void;
  onOpenAIAdvisor: () => void;
  onExportExcel: () => void;
  onExportPDF: () => void;
  onOpenQRModal: () => void;
  activeTab: 'jars' | 'transactions' | 'crypto' | 'analytics';
  setActiveTab: (tab: 'jars' | 'transactions' | 'crypto' | 'analytics') => void;
  isAmountsHidden: boolean;
  onToggleHideAmounts: () => void;
  onOpenAuthModal?: () => void;
  userEmail?: string | null;
}

export const Navbar: React.FC<NavbarProps> = ({
  monthlyIncome,
  totalSpent,
  totalAllocated,
  onOpenIncomeModal,
  onOpenTransactionModal,
  onOpenBankSyncModal,
  onOpenAIAdvisor,
  onExportExcel,
  onExportPDF,
  onOpenQRModal,
  activeTab,
  setActiveTab,
  isAmountsHidden,
  onToggleHideAmounts,
  onOpenAuthModal,
  userEmail,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#09090b]/90 backdrop-blur-md text-zinc-100 pt-4 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="bg-[#121214] border border-zinc-800 rounded-3xl px-6 py-3.5 shadow-xl flex items-center justify-between">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Wallet className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-lg tracking-tight text-white">RoFinance</span>
                <span className="bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/20">
                  Database Local
                </span>
              </div>
              <p className="text-xs text-zinc-400 hidden sm:block">Quản lý dòng tiền & Tài sản số</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="hidden md:flex items-center space-x-1 bg-[#1c1c20] p-1 rounded-2xl border border-zinc-800">
            <button
              onClick={() => setActiveTab('jars')}
              className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'jars'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              Hũ Tài Chính
            </button>
            <button
              onClick={() => setActiveTab('transactions')}
              className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'transactions'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              Chi Tiêu
            </button>
            <button
              onClick={() => setActiveTab('crypto')}
              className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                activeTab === 'crypto'
                  ? 'bg-amber-500 text-zinc-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-amber-400/90 hover:text-amber-300 hover:bg-zinc-800/60'
              }`}
            >
              <Coins className="w-3.5 h-3.5" />
              <span>Tài Sản Số (Crypto)</span>
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                activeTab === 'analytics'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              <PieChart className="w-3.5 h-3.5" />
              <span>Thống Kê</span>
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            {/* AUTH / SECURITY BUTTON */}
            {onOpenAuthModal && (
              <button
                onClick={onOpenAuthModal}
                className="p-2.5 rounded-xl text-xs font-bold transition-all border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 flex items-center space-x-1.5"
                title="Bảo mật Auth & Tài khoản"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="hidden xl:inline text-[11px]">
                  {userEmail ? userEmail.split('@')[0] : 'Bảo Mật Auth'}
                </span>
              </button>
            )}

            {/* HIDE / SHOW BALANCES TOGGLE BUTTON */}
            <button
              onClick={onToggleHideAmounts}
              className={`p-2.5 rounded-xl text-xs font-bold transition-all border flex items-center space-x-1.5 ${
                isAmountsHidden
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  : 'bg-[#1c1c20] text-zinc-400 hover:text-white border-zinc-800'
              }`}
              title={isAmountsHidden ? 'Hiển thị số tiền' : 'Ẩn số tiền (Chế độ riêng tư)'}
            >
              {isAmountsHidden ? (
                <>
                  <EyeOff className="w-4 h-4 text-amber-400" />
                  <span className="hidden xl:inline text-[11px]">Đã Ẩn Tiền</span>
                </>
              ) : (
                <>
                  <Eye className="w-4 h-4" />
                  <span className="hidden xl:inline text-[11px]">Ẩn Số Tiền</span>
                </>
              )}
            </button>

            <button
              onClick={onOpenIncomeModal}
              className="px-3.5 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-all flex items-center space-x-1.5 shadow-md shadow-emerald-600/10"
              title="Cập nhật thu nhập hàng tháng"
            >
              <Wallet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Phân Bổ Lương</span>
              <span className="sm:hidden">Lương</span>
            </button>

            <button
              onClick={onOpenTransactionModal}
              className="px-3.5 py-2 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition-all flex items-center space-x-1.5 shadow-md shadow-indigo-600/20"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Thêm Chi Tiêu</span>
              <span className="sm:hidden">+ Chi</span>
            </button>

            <button
              onClick={onOpenQRModal}
              className="px-3 py-2 text-xs font-bold rounded-xl bg-[#1c1c20] hover:bg-zinc-800 text-amber-400 border border-amber-500/30 transition-all flex items-center space-x-1.5"
              title="Tạo lệnh chuyển tiền VietQR"
            >
              <QrCode className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Chuyển QR</span>
            </button>

            <button
              onClick={onOpenBankSyncModal}
              className="p-2 text-zinc-400 hover:text-white hover:bg-[#1c1c20] bg-[#121214] rounded-xl transition-all border border-zinc-800"
              title="Đồng bộ Ngân hàng"
            >
              <Landmark className="w-4 h-4" />
            </button>

            {/* AI Advisor Button */}
            <button
              onClick={onOpenAIAdvisor}
              className="px-3.5 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white transition-all flex items-center space-x-1.5 shadow-md shadow-purple-600/20"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span className="hidden lg:inline">Trợ Lý AI</span>
            </button>

            {/* Export Dropdown */}
            <div className="relative group">
              <button className="p-2 text-zinc-400 hover:text-white hover:bg-[#1c1c20] bg-[#121214] rounded-xl transition-all border border-zinc-800 flex items-center">
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              </button>
              <div className="absolute right-0 mt-2 w-48 bg-[#18181b] rounded-2xl shadow-2xl border border-zinc-800 py-1.5 hidden group-hover:block group-focus-within:block z-50">
                <div className="px-3 py-1 text-[10px] font-bold text-zinc-500 uppercase tracking-wider">
                  Xuất Báo Cáo
                </div>
                <button
                  onClick={onExportExcel}
                  className="w-full text-left px-3 py-2 text-xs text-zinc-300 hover:bg-zinc-800 flex items-center space-x-2 transition-colors"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  <span>File Excel (.xlsx)</span>
                </button>
                <button
                  onClick={onExportPDF}
                  className="w-full text-left px-3 py-2 text-xs text-zinc-300 hover:bg-zinc-800 flex items-center space-x-2 transition-colors"
                >
                  <Printer className="w-4 h-4 text-sky-400" />
                  <span>In / File PDF</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Tab bar below navbar */}
        <div className="md:hidden flex items-center justify-around py-2 my-2 bg-[#121214] rounded-2xl border border-zinc-800 text-xs font-medium overflow-x-auto space-x-1 px-2">
          <button
            onClick={() => setActiveTab('jars')}
            className={`py-1 px-3 rounded-lg shrink-0 ${activeTab === 'jars' ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-400'}`}
          >
            Hũ Tài Chính
          </button>
          <button
            onClick={() => setActiveTab('transactions')}
            className={`py-1 px-3 rounded-lg shrink-0 ${
              activeTab === 'transactions' ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-400'
            }`}
          >
            Chi Tiêu
          </button>
          <button
            onClick={() => setActiveTab('crypto')}
            className={`py-1 px-3 rounded-lg shrink-0 ${
              activeTab === 'crypto' ? 'bg-amber-500 text-zinc-950 font-bold' : 'text-amber-400'
            }`}
          >
            Tài Sản Số
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`py-1 px-3 rounded-lg shrink-0 ${
              activeTab === 'analytics' ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-400'
            }`}
          >
            Thống Kê
          </button>
        </div>
      </div>
    </header>
  );
};

