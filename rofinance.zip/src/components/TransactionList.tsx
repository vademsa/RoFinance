import React, { useState } from 'react';
import { Search, Filter, Trash2, ArrowUpRight, ArrowDownLeft, Calendar, Tag, Building2, PlusCircle } from 'lucide-react';
import { Jar, Transaction } from '../types';
import { formatVND, formatDateVI } from '../utils/formatters';

interface TransactionListProps {
  transactions: Transaction[];
  jars: Jar[];
  onDeleteTransaction: (id: string) => void;
  onOpenTransactionModal: () => void;
  isAmountsHidden?: boolean;
}

export const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  jars,
  onDeleteTransaction,
  onOpenTransactionModal,
  isAmountsHidden = false,
}) => {

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedJarFilter, setSelectedJarFilter] = useState<string>('ALL');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('ALL');

  const filteredTransactions = transactions.filter((tx) => {
    const matchesSearch =
      tx.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.category.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesJar = selectedJarFilter === 'ALL' || tx.jarId === selectedJarFilter;
    const matchesType = selectedTypeFilter === 'ALL' || tx.type === selectedTypeFilter;

    return matchesSearch && matchesJar && matchesType;
  });

  return (
    <div className="bg-[#121214] rounded-[28px] border border-zinc-800 shadow-xl p-6 space-y-6 text-zinc-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white tracking-tight">Nhật Ký Giao Dịch Dòng Tiền</h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Lịch sử biến động thu chi và phân bổ hũ tài chính được lưu trữ bảo mật
          </p>
        </div>

        <button
          onClick={onOpenTransactionModal}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition-all flex items-center space-x-1.5 self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Ghi Nhận Giao Dịch Mới</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#1c1c20] p-3 rounded-2xl border border-zinc-800">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo nội dung, danh mục..."
            className="w-full pl-9 pr-3 py-2 text-xs font-medium bg-[#121214] border border-zinc-700 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Jar Filter */}
        <div>
          <select
            value={selectedJarFilter}
            onChange={(e) => setSelectedJarFilter(e.target.value)}
            className="w-full p-2 text-xs font-bold bg-[#121214] border border-zinc-700 rounded-xl text-zinc-200 focus:outline-none focus:border-indigo-500"
          >
            <option value="ALL">Tất cả Hũ Tài Chính</option>
            {jars.map((j) => (
              <option key={j.id} value={j.id}>
                Hũ {j.name} ({j.code})
              </option>
            ))}
          </select>
        </div>

        {/* Type Filter */}
        <div>
          <select
            value={selectedTypeFilter}
            onChange={(e) => setSelectedTypeFilter(e.target.value)}
            className="w-full p-2 text-xs font-bold bg-[#121214] border border-zinc-700 rounded-xl text-zinc-200 focus:outline-none focus:border-indigo-500"
          >
            <option value="ALL">Tất cả loại giao dịch</option>
            <option value="expense">Chỉ xem Chi tiêu</option>
            <option value="income">Chỉ xem Thu nhập</option>
            <option value="transfer">Chỉ xem Chuyển hũ</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="border border-zinc-800 rounded-2xl overflow-hidden shadow-lg bg-[#18181b]/50">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-[#18181b] text-zinc-400 text-[11px] font-bold uppercase tracking-wider border-b border-zinc-800">
                <th className="p-3.5">Ngày</th>
                <th className="p-3.5">Nội dung & Danh mục</th>
                <th className="p-3.5">Hũ Tài Chính</th>
                <th className="p-3.5">Ngân hàng</th>
                <th className="p-3.5 text-right">Số tiền</th>
                <th className="p-3.5 text-center">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80 text-xs">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-zinc-500 font-medium">
                    Không tìm thấy giao dịch nào phù hợp.
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((tx) => {
                  const jar = jars.find((j) => j.id === tx.jarId);
                  const isIncome = tx.type === 'income';

                  return (
                    <tr key={tx.id} className="hover:bg-[#1c1c20] transition-colors">
                      <td className="p-3.5 font-mono text-zinc-400">{formatDateVI(tx.date)}</td>
                      <td className="p-3.5">
                        <div className="font-bold text-white">{tx.description}</div>
                        <div className="text-[11px] text-zinc-400 flex items-center space-x-1 mt-0.5">
                          <Tag className="w-3 h-3 text-zinc-500" />
                          <span>{tx.category}</span>
                        </div>
                      </td>
                      <td className="p-3.5">
                        {jar ? (
                          <span
                            className="px-2.5 py-1 rounded-full text-[10px] font-bold text-white inline-block shadow-sm"
                            style={{ backgroundColor: jar.color }}
                          >
                            {jar.code} - {jar.name}
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="p-3.5 font-medium text-zinc-300">{tx.bankName || jar?.bankName || '-'}</td>
                      <td className="p-3.5 text-right font-black font-mono text-sm">
                        <span className={isIncome ? 'text-emerald-400' : 'text-zinc-100'}>
                          {isIncome ? '+' : '-'}{formatVND(tx.amount, isAmountsHidden)}
                        </span>
                      </td>

                      <td className="p-3.5 text-center">
                        <button
                          onClick={() => onDeleteTransaction(tx.id)}
                          className="p-1.5 text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                          title="Xóa giao dịch"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
