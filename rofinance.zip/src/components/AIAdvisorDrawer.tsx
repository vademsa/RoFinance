import React, { useState } from 'react';
import { X, Sparkles, Send, Bot, User, Loader2, Lightbulb, ShieldCheck } from 'lucide-react';
import { Jar, Transaction } from '../types';

interface AIAdvisorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  jars: Jar[];
  monthlyIncome: number;
  transactions: Transaction[];
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
}

export const AIAdvisorDrawer: React.FC<AIAdvisorDrawerProps> = ({
  isOpen,
  onClose,
  jars,
  monthlyIncome,
  transactions,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: 'Xin chào! Tôi là Trợ lý Tài chính AI Gemini. Tôi đã phân tích sơ bộ mô hình 6 Hũ Tài Chính và lịch sử giao dịch của bạn. Bạn muốn tôi hỗ trợ tối ưu ngân sách hay giải đáp thắc mắc tài chính nào hôm nay?',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSendMessage = async (queryText?: string) => {
    const textToSend = queryText || input;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend,
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/financial-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userQuery: textToSend,
          jars,
          monthlyIncome,
          recentTransactions: transactions.slice(0, 10),
        }),
      });

      const data = await res.json();

      if (data.success && data.reply) {
        setMessages((prev) => [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            sender: 'ai',
            text: data.reply,
          },
        ]);
      } else {
        throw new Error(data.error || 'Có lỗi xảy ra khi hỏi Gemini');
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: `⚠️ Rất tiếc, Trợ lý AI đang gặp sự cố kết nối: ${err.message}. Lời khuyên tạm thời: Bạn nên kiểm tra kỹ hũ có mức chi tiêu >80% để tái phân bổ nguồn thu!`,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-md">
      <div className="bg-[#18181b] w-full max-w-lg h-full shadow-2xl flex flex-col border-l border-zinc-800 text-zinc-100 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="bg-[#121214] text-white p-5 flex items-center justify-between border-b border-zinc-800">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 text-indigo-400">
              <Sparkles className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-base font-black text-white tracking-tight">Trợ Lý Tài Chính AI Gemini</h2>
              <p className="text-[11px] text-zinc-400">Tư vấn phân bổ hũ tài chính thông minh</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1.5 rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Question Prompts */}
        <div className="bg-[#121214] p-3.5 border-b border-zinc-800 space-y-2">
          <div className="text-[10px] uppercase font-bold text-indigo-400 tracking-wider flex items-center space-x-1">
            <Lightbulb className="w-3 h-3 text-indigo-400" />
            <span>Gợi ý câu hỏi nhanh:</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {[
              'Phân tích tổng quan hũ tài chính của tôi',
              'Làm sao để cắt giảm chi tiêu hũ Trả Nợ DEBT?',
              'Tư vấn đầu tư cho hũ Tự do tài chính FFA',
            ].map((promptText, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(promptText)}
                disabled={isLoading}
                className="px-2.5 py-1.5 bg-[#1c1c20] hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-[11px] font-semibold rounded-xl transition-all text-left disabled:opacity-50"
              >
                {promptText}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Messages Log */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#121214]">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex items-start space-x-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 text-xs shadow-md mt-1">
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                <div
                  className={`p-3.5 rounded-2xl text-xs leading-relaxed max-w-[85%] whitespace-pre-wrap shadow-md ${
                    isUser
                      ? 'bg-indigo-600 text-white font-medium rounded-br-none'
                      : 'bg-[#1c1c20] text-zinc-100 border border-zinc-800 font-normal rounded-bl-none'
                  }`}
                >
                  {msg.text}
                </div>
                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-zinc-800 text-white flex items-center justify-center shrink-0 text-xs shadow-md mt-1 border border-zinc-700">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center space-x-2 text-xs text-indigo-400 bg-[#1c1c20] p-3 rounded-2xl w-fit border border-zinc-800">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
              <span>Gemini AI đang phân tích dữ liệu hũ tài chính...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-[#121214] border-t border-zinc-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center space-x-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Hỏi AI về cách quản lý dòng tiền, hũ tài chính..."
              className="flex-1 p-3 text-xs bg-[#1c1c20] border border-zinc-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-zinc-500 font-medium"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="p-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition-all disabled:opacity-50 shrink-0 shadow-lg shadow-indigo-600/20"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
