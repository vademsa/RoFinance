import React, { useState } from 'react';
import { X, Plus, AlertTriangle, AlertCircle, ArrowUpRight, ArrowDownLeft, RefreshCw, Calendar, Tag, Building2 } from 'lucide-react';
import { Jar, Transaction } from '../types';
import { CATEGORIES_BY_JAR_CODE, BANK_OPTIONS } from '../constants/defaultData';
import { formatVND } from '../utils/formatters';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  jars: Jar[];
  onAddTransaction: (newTx: Omit<Transaction, 'id'>) => void;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  jars,
  onAddTransaction,
}) => {
  const [type, setType] = useState<'expense' | 'income' | 'transfer'>('expense');
  const [amount, setAmount] = useState<number>(150000);
  const [jarId, setJarId] = useState<string>(jars[0]?.id || '');
  const [category, setCategory] = useState<string>('Ăn uống & Giải trí');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState<string>('');
  const [bankName, setBankName] = useState<string>('Techcombank');

  if (!isOpen) return null;

  const selectedJar = jars.find((j) => j.id === jarId) || jars[0];
  const categories = CATEGORIES_BY_JAR_CODE[selectedJar?.code] || [
    'Ăn uống',
    'Mua sắm',
    'Hóa đơn',
    'Khác',
  ];

  // Budget alert simulation before submission
  const projectedSpent = (selectedJar?.currentSpent || 0) + (type === 'expense' ? amount : 0);
  const projectedPercentage = selectedJar?.targetBudget > 0 ? (projectedSpent / selectedJar.targetBudget) * 100 : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) return;

    onAddTransaction({
      type,
      amount,
      jarId: type === 'expense' ? jarId : jarId,
      category,
      date,
      description: description || (type === 'expense' ? 'Chi tiêu cá nhân' : 'Thu nhập bổ sung'),
      bankName,
    });

    // Reset form
    setAmount(150000);
    setDescription('');
    onClose();
  };

  const handleQuickAddAmount = (addValue: number) => {
    setAmount((prev) => prev + addValue);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-[#18181b] rounded-[32px] shadow-2xl max-w-lg w-full overflow-hidden border border-zinc-800 my-8 text-zinc-100">
        {/* Header */}
        <div className="bg-[#121214] text-white p-5 flex items-center justify-between border-b border-zinc-800">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20">
              <Plus className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-black tracking-tight">Thêm Giao Dịch Mới</h2>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1.5 rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Type Selector Tabs */}
          <div className="grid grid-cols-3 gap-2 bg-[#121214] p-1.5 rounded-2xl border border-zinc-800">
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center space-x-1.5 ${
                type === 'expense'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>Chi Tiêu</span>
            </button>
            <button
              type="button"
              onClick={() => setType('income')}
              className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center space-x-1.5 ${
                type === 'income'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>Thu Nhập</span>
            </button>
            <button
              type="button"
              onClick={() => setType('transfer')}
              className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center space-x-1.5 ${
                type === 'transfer'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              <RefreshCw className="w-4 h-4" />
              <span>Chuyển Hũ</span>
            </button>
          </div>

          {/* Amount Field */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-400">
              Số Tiền (VNĐ)
            </label>
            <div className="relative">
              <input
                type="number"
                value={amount || ''}
                onChange={(e) => setAmount(Number(e.target.value))}
                placeholder="150,000"
                required
                min={1000}
                className="w-full pl-4 pr-16 py-3.5 text-2xl font-black font-mono text-white bg-[#121214] border border-zinc-700 rounded-2xl focus:border-indigo-500 focus:outline-none transition-all"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-black text-zinc-400">
                VNĐ
              </span>
            </div>

            {/* Quick Add Buttons */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[50000, 100000, 200000, 500000, 1000000].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => handleQuickAddAmount(val)}
                  className="px-2.5 py-1 bg-[#1c1c20] hover:bg-zinc-800 text-zinc-300 text-xs font-mono font-bold rounded-xl border border-zinc-800 transition-colors"
                >
                  +{formatVND(val)}
                </button>
              ))}
            </div>
          </div>

          {/* Jar Selection */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-400">
              Hũ Tài Chính Liên Kết
            </label>
            <select
              value={jarId}
              onChange={(e) => {
                setJarId(e.target.value);
                const newJar = jars.find((j) => j.id === e.target.value);
                if (newJar) {
                  const newCats = CATEGORIES_BY_JAR_CODE[newJar.code];
                  if (newCats && newCats[0]) setCategory(newCats[0]);
                }
              }}
              className="w-full p-3 bg-[#121214] border border-zinc-700 rounded-2xl font-bold text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              {jars.map((j) => (
                <option key={j.id} value={j.id}>
                  {j.name} ({j.code}) - Hạn mức {formatVND(j.targetBudget)}
                </option>
              ))}
            </select>
          </div>

          {/* Live Warning Banner if Expense > 80% or > 100% */}
          {type === 'expense' && projectedPercentage >= 80 && (
            <div
              className={`p-3.5 rounded-2xl border flex items-start space-x-2.5 text-xs ${
                projectedPercentage > 100
                  ? 'bg-rose-950/30 border-rose-500/50 text-rose-200'
                  : 'bg-amber-950/30 border-amber-500/50 text-amber-200'
              }`}
            >
              {projectedPercentage > 100 ? (
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              )}
              <div>
                <div className="font-bold">
                  {projectedPercentage > 100
                    ? '⚠️ CẢNH BÁO: Giao dịch này sẽ vượt quá hạn mức hũ!'
                    : '⚡ Nhắc Nhở: Hũ này đã sử dụng hơn 80% hạn mức tháng'}
                </div>
                <div className="mt-0.5 opacity-90 font-mono">
                  Dự kiến tổng chi: {formatVND(projectedSpent)} / Hạn mức: {formatVND(selectedJar?.targetBudget || 0)} (
                  {projectedPercentage.toFixed(1)}%)
                </div>
              </div>
            </div>
          )}

          {/* Category & Bank Row */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-zinc-400">
                Danh Mục
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-3 bg-[#121214] border border-zinc-700 rounded-2xl font-semibold text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-zinc-400">
                Phương Thức / Ngân Hàng
              </label>
              <select
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-full p-3 bg-[#121214] border border-zinc-700 rounded-2xl font-semibold text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                {BANK_OPTIONS.map((b) => (
                  <option key={b.code} value={b.shortName}>
                    {b.shortName}
                  </option>
                ))}
                <option value="Tiền mặt">Tiền mặt</option>
              </select>
            </div>
          </div>

          {/* Date & Description */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-zinc-400">
                Ngày Giao Dịch
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-3 bg-[#121214] border border-zinc-700 rounded-2xl font-medium text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-zinc-400">
                Ghi Chú Nội Dung
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="VD: Cà phê sáng cùng khách hàng"
                className="w-full p-3 bg-[#121214] border border-zinc-700 rounded-2xl font-medium text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="pt-3 flex items-center justify-end space-x-3 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl border border-zinc-700 text-zinc-300 font-bold text-xs hover:bg-zinc-800 transition-colors"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-all shadow-lg shadow-indigo-600/20"
            >
              Lưu Giao Dịch
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
