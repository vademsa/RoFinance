import React, { useState } from 'react';
import { X, Lock, Mail, KeyRound, UserCheck, LogOut, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, auth } from '../lib/firebase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string | null;
  userEmail?: string | null;
  isAnonymous?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  userId,
  userEmail,
  isAnonymous,
}) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsLoading(true);

    try {
      if (isSignUp) {
        await createUserWithEmailAndPassword(auth, email, password);
        setSuccessMsg('Đăng ký tài khoản thành công! Dữ liệu của bạn được mã hóa & lưu bảo mật.');
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        setSuccessMsg('Đăng nhập thành công! Đã kết nối dữ liệu của bạn.');
      }
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Thao tác không thành công. Vui lòng kiểm tra lại email & mật khẩu.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setSuccessMsg('Đã đăng xuất khỏi tài khoản.');
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err: any) {
      setErrorMsg('Lỗi đăng xuất: ' + err.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-[#18181b] rounded-[32px] shadow-2xl max-w-md w-full overflow-hidden border border-zinc-800 text-zinc-100 my-8">
        {/* Header */}
        <div className="bg-[#121214] text-white p-6 relative border-b border-zinc-800">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-zinc-400 hover:text-white p-1.5 rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 text-indigo-400">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-tight">
                Xác Thực Tài Khoản & Bảo Mật
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Bảo vệ dữ liệu tài chính với Firestore Rules & Firebase Authentication
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Status info */}
          <div className="bg-[#121214] p-4 rounded-2xl border border-zinc-800 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-zinc-400 font-bold uppercase text-[10px]">Trạng Thái Xác Thực:</span>
              <span className="flex items-center space-x-1.5 text-emerald-400 font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>Đã Xác Thực (Authenticated)</span>
              </span>
            </div>
            <div className="text-zinc-300 font-mono text-[11px] break-all">
              User UID: <span className="text-indigo-300">{userId || 'Loading...'}</span>
            </div>
            {userEmail && (
              <div className="text-emerald-300 font-bold">
                Email: {userEmail}
              </div>
            )}
            <div className="text-zinc-500 text-[11px]">
              Quyền truy cập Firestore: Chỉ duy nhất tài khoản này (`request.auth.uid == userId`) mới có quyền Đọc/Ghi dữ liệu hũ & tài sản.
            </div>
          </div>

          {userEmail ? (
            <div className="space-y-3">
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 rounded-xl text-xs flex items-center space-x-2">
                <UserCheck className="w-5 h-5 text-emerald-400" />
                <span>Bạn đang đăng nhập bằng email <strong className="text-white">{userEmail}</strong>.</span>
              </div>
              <button
                onClick={handleSignOut}
                className="w-full py-2.5 bg-rose-600/10 hover:bg-rose-600/20 text-rose-300 border border-rose-500/20 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-2"
              >
                <LogOut className="w-4 h-4 text-rose-400" />
                <span>Đăng Xuất Tài Khoản</span>
              </button>
            </div>
          ) : (
            /* Sign in / Sign up form */
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex items-center justify-between text-xs font-bold border-b border-zinc-800 pb-2">
                <button
                  type="button"
                  onClick={() => setIsSignUp(false)}
                  className={`pb-1 ${!isSignUp ? 'text-indigo-400 border-b-2 border-indigo-500' : 'text-zinc-500'}`}
                >
                  Đăng Nhập
                </button>
                <button
                  type="button"
                  onClick={() => setIsSignUp(true)}
                  className={`pb-1 ${isSignUp ? 'text-indigo-400 border-b-2 border-indigo-500' : 'text-zinc-500'}`}
                >
                  Tạo Tài Khoản Mới
                </button>
              </div>

              {errorMsg && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-xl text-xs">
                  {errorMsg}
                </div>
              )}

              {successMsg && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded-xl text-xs flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{successMsg}</span>
                </div>
              )}

              <div className="space-y-1 text-xs">
                <label className="font-bold text-zinc-300 flex items-center space-x-1">
                  <Mail className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Địa chỉ Email</span>
                </label>
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-3.5 py-2.5 bg-[#121214] border border-zinc-800 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1 text-xs">
                <label className="font-bold text-zinc-300 flex items-center space-x-1">
                  <KeyRound className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Mật khẩu bảo mật</span>
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full px-3.5 py-2.5 bg-[#121214] border border-zinc-800 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                <Lock className="w-4 h-4" />
                <span>{isLoading ? 'Đang xử lý...' : isSignUp ? 'Tạo Tài Khoản Mới' : 'Đăng Nhập Bảo Mật'}</span>
              </button>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="bg-[#121214] p-4 border-t border-zinc-800 text-center">
          <button
            onClick={onClose}
            className="text-xs font-bold text-zinc-400 hover:text-white transition-colors"
          >
            Đóng Cửa Sổ
          </button>
        </div>
      </div>
    </div>
  );
};
