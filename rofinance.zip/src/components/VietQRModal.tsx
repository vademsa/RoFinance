import React, { useState } from 'react';
import { X, QrCode, Check, Copy, Download, Building2, Wallet, ArrowRight, ShieldCheck } from 'lucide-react';
import { Jar } from '../types';
import { formatVND, getVietQRUrl } from '../utils/formatters';

interface VietQRModalProps {
  isOpen: boolean;
  onClose: () => void;
  jars: Jar[];
  monthlyIncome: number;
}

export const VietQRModal: React.FC<VietQRModalProps> = ({ isOpen, onClose, jars, monthlyIncome }) => {
  const [selectedJarId, setSelectedJarId] = useState<string>(jars[0]?.id || '');
  const [completedTransferIds, setCompletedTransferIds] = useState<Record<string, boolean>>({});
  const [copiedField, setCopiedField] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentJar = jars.find((j) => j.id === selectedJarId) || jars[0];

  const toggleCompleted = (jarId: string) => {
    setCompletedTransferIds((prev) => ({
      ...prev,
      [jarId]: !prev[jarId],
    }));
  };

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const qrUrl = currentJar
    ? getVietQRUrl(
        currentJar.bankCode,
        currentJar.accountNumber,
        currentJar.targetBudget,
        `Phan bo quy ${currentJar.code}`,
        currentJar.accountName
      )
    : '';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-[#18181b] rounded-[32px] shadow-2xl max-w-4xl w-full overflow-hidden border border-zinc-800 my-8 text-zinc-100">
        {/* Header */}
        <div className="bg-[#121214] text-white p-6 relative border-b border-zinc-800">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-zinc-400 hover:text-white p-1.5 rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-amber-500/10 text-amber-400 rounded-2xl border border-amber-500/20">
              <QrCode className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-tight">Lệnh Chuyển Tiền VietQR Phân Bổ Hũ</h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Quét mã VietQR bằng ứng dụng ngân hàng để nạp tiền tự động vào quỹ tiết kiệm & đầu tư
              </p>
            </div>
          </div>
        </div>

        {/* Jar Tabs */}
        <div className="bg-[#121214] px-6 py-3 border-b border-zinc-800/80 flex items-center space-x-2 overflow-x-auto">
          {jars.map((jar) => {
            const isCompleted = completedTransferIds[jar.id];
            const isSelected = jar.id === selectedJarId;
            return (
              <button
                key={jar.id}
                onClick={() => setSelectedJarId(jar.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 shrink-0 ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                    : isCompleted
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : 'bg-[#1c1c20] text-zinc-300 border border-zinc-800 hover:bg-zinc-800'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: jar.color }} />
                <span>{jar.code}</span>
                <span className="text-[10px] opacity-80">({jar.percentage}%)</span>
                {isCompleted && <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />}
              </button>
            );
          })}
        </div>

        {/* Main Body */}
        {currentJar && (
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Left Column: VietQR Image */}
            <div className="flex flex-col items-center justify-center p-6 bg-[#121214] rounded-2xl border border-zinc-800 text-center">
              <div className="bg-white p-4 rounded-2xl shadow-xl relative group">
                <img
                  src={qrUrl}
                  alt={`VietQR ${currentJar.name}`}
                  className="w-64 h-64 object-contain rounded-lg"
                  onError={(e) => {
                    // Fallback QR code generator if api image is offline
                    (e.target as HTMLImageElement).src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(
                      `VietQR:${currentJar.bankCode}:${currentJar.accountNumber}:${currentJar.targetBudget}`
                    )}`;
                  }}
                />
              </div>

              <div className="mt-4 flex items-center space-x-2 text-xs text-emerald-400 bg-emerald-500/10 px-3.5 py-1.5 rounded-full border border-emerald-500/30">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold">Chuẩn VietQR Chuyển Khoản Nhanh 24/7 NAPAS</span>
              </div>
            </div>

            {/* Right Column: Transfer Info */}
            <div className="space-y-4">
              <div className="border-b border-zinc-800 pb-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold text-zinc-400">Hũ Tài Chính Target</span>
                  <span
                    className="text-xs font-black px-2.5 py-0.5 rounded-full text-white shadow-sm"
                    style={{ backgroundColor: currentJar.color }}
                  >
                    {currentJar.code} - {currentJar.percentage}%
                  </span>
                </div>
                <h3 className="text-xl font-black text-white mt-1">{currentJar.name}</h3>
                <p className="text-xs text-zinc-400 mt-0.5">{currentJar.description}</p>
              </div>

              {/* Amount Box */}
              <div className="bg-[#121214] border border-indigo-500/30 p-4 rounded-2xl">
                <div className="text-xs text-indigo-400 font-bold uppercase tracking-wider">Số tiền cần phân bổ:</div>
                <div className="text-2xl font-black font-mono text-white mt-1">
                  {formatVND(currentJar.targetBudget)}
                </div>
              </div>

              {/* Details List */}
              <div className="space-y-2.5 text-xs">
                {/* Bank */}
                <div className="flex items-center justify-between p-3 bg-[#121214] rounded-xl border border-zinc-800">
                  <span className="text-zinc-400 font-medium">Ngân hàng thụ hưởng:</span>
                  <span className="font-bold text-white flex items-center space-x-1.5">
                    <Building2 className="w-3.5 h-3.5 text-indigo-400" />
                    <span>{currentJar.bankName}</span>
                  </span>
                </div>

                {/* Account Number */}
                <div className="flex items-center justify-between p-3 bg-[#121214] rounded-xl border border-zinc-800">
                  <span className="text-zinc-400 font-medium">Số tài khoản:</span>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold font-mono text-white text-sm tracking-wider">
                      {currentJar.accountNumber}
                    </span>
                    <button
                      onClick={() => copyToClipboard(currentJar.accountNumber, 'account')}
                      className="text-indigo-400 hover:text-indigo-300 p-1"
                      title="Sao chép STK"
                    >
                      {copiedField === 'account' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Account Holder */}
                <div className="flex items-center justify-between p-3 bg-[#121214] rounded-xl border border-zinc-800">
                  <span className="text-zinc-400 font-medium">Tên tài khoản:</span>
                  <span className="font-bold text-white">{currentJar.accountName}</span>
                </div>

                {/* Memo */}
                <div className="flex items-center justify-between p-3 bg-[#121214] rounded-xl border border-zinc-800">
                  <span className="text-zinc-400 font-medium">Nội dung chuyển tiền:</span>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-zinc-200">Phan bo quy {currentJar.code}</span>
                    <button
                      onClick={() => copyToClipboard(`Phan bo quy ${currentJar.code}`, 'memo')}
                      className="text-indigo-400 hover:text-indigo-300 p-1"
                      title="Sao chép nội dung"
                    >
                      {copiedField === 'memo' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Status Toggle Button */}
              <button
                onClick={() => toggleCompleted(currentJar.id)}
                className={`w-full py-3 rounded-2xl font-bold text-xs transition-all flex items-center justify-center space-x-2 ${
                  completedTransferIds[currentJar.id]
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20'
                    : 'bg-[#121214] hover:bg-zinc-800 text-zinc-300 border border-zinc-700'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>
                  {completedTransferIds[currentJar.id]
                    ? 'Đã Hoàn Thành Chuyển Tiền Vào Hũ'
                    : 'Đánh Dấu Đã Chuyển Tiền'}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="bg-[#121214] p-4 border-t border-zinc-800 flex items-center justify-between">
          <div className="text-xs text-zinc-400 font-medium">
            Đã hoàn thành: <strong className="text-white font-mono">{Object.values(completedTransferIds).filter(Boolean).length}</strong> / {jars.length} hũ
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-xl transition-colors border border-zinc-700"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
