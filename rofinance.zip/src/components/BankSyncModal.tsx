import React, { useState } from 'react';
import { X, Landmark, RefreshCw, CheckCircle2, ShieldCheck, Lock, ExternalLink, Smartphone } from 'lucide-react';
import { BankAccount } from '../types';
import { formatVND } from '../utils/formatters';

interface BankSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  bankAccounts: BankAccount[];
  onSyncBank: (bankCode: string) => Promise<void>;
  isAmountsHidden?: boolean;
}

export const BankSyncModal: React.FC<BankSyncModalProps> = ({
  isOpen,
  onClose,
  bankAccounts,
  onSyncBank,
  isAmountsHidden = false,
}) => {

  const [syncingCode, setSyncingCode] = useState<string | null>(null);
  const [syncLogs, setSyncLogs] = useState<string[]>([]);

  if (!isOpen) return null;

  const handleSync = async (code: string) => {
    setSyncingCode(code);
    setSyncLogs((prev) => [
      `[${new Date().toLocaleTimeString()}] Đang gửi yêu cầu mã hóa tới API ngân hàng ${code}...`,
      ...prev,
    ]);

    await onSyncBank(code);

    setSyncLogs((prev) => [
      `[${new Date().toLocaleTimeString()}] Đồng bộ thành công số dư ngân hàng ${code}!`,
      ...prev,
    ]);
    setSyncingCode(null);
  };

  const handleSyncAll = async () => {
    for (const acc of bankAccounts) {
      await handleSync(acc.bankCode);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-[#18181b] rounded-[32px] shadow-2xl max-w-2xl w-full overflow-hidden border border-zinc-800 my-8 text-zinc-100">
        {/* Header */}
        <div className="bg-[#121214] text-white p-6 relative border-b border-zinc-800">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-zinc-400 hover:text-white p-1.5 rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20">
              <Landmark className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-tight">Kết Nối & Kiểm Tra Tài Khoản Ngân Hàng</h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Kiểm tra số dư thực tế qua Open Banking API bảo mật mã hóa SSL 256-bit
              </p>
            </div>
          </div>
        </div>

        {/* Security Badge */}
        <div className="bg-emerald-500/10 px-6 py-2.5 border-b border-emerald-500/20 flex items-center space-x-2 text-xs text-emerald-400 font-semibold">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Kết nối ngân hàng tuân thủ chuẩn an toàn Open Banking & Mã hóa thiết bị đầu cuối.</span>
        </div>

        {/* Bank List */}
        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300">Tài Khoản Ngân Hàng Đã Liên Kết</h3>
            <button
              onClick={handleSyncAll}
              disabled={!!syncingCode}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition-all flex items-center space-x-1.5 disabled:opacity-50 shadow-md shadow-indigo-600/20"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncingCode ? 'animate-spin' : ''}`} />
              <span>Đồng Bộ Tất Cả</span>
            </button>
          </div>

          <div className="space-y-3">
            {bankAccounts.map((acc) => (
              <div
                key={acc.id}
                className="p-4 rounded-2xl border border-zinc-800 bg-[#121214] hover:border-zinc-700 transition-all flex items-center justify-between"
              >
                <div className="flex items-center space-x-3.5">
                  <div className="w-10 h-10 rounded-xl bg-[#1c1c20] border border-zinc-700 flex items-center justify-center font-black text-xs text-indigo-400 shadow-sm">
                    {acc.bankCode}
                  </div>
                  <div>
                    <div className="font-extrabold text-white text-sm">{acc.bankName}</div>
                    <div className="text-xs text-zinc-400 font-mono mt-0.5">
                      STK: {acc.accountNumber} • {acc.accountHolder}
                    </div>
                    <div className="text-[10px] text-zinc-500 mt-0.5">Cập nhật: {acc.lastSynced}</div>
                  </div>
                </div>

                <div className="text-right space-y-1.5">
                  <div className="text-base font-black font-mono text-white">{formatVND(acc.balance, isAmountsHidden)}</div>
                  <button

                    onClick={() => handleSync(acc.bankCode)}
                    disabled={syncingCode === acc.bankCode}
                    className="px-3 py-1 text-[11px] font-bold bg-[#1c1c20] hover:bg-zinc-800 text-indigo-300 border border-zinc-700 rounded-xl transition-colors inline-flex items-center space-x-1"
                  >
                    <RefreshCw className={`w-3 h-3 ${syncingCode === acc.bankCode ? 'animate-spin' : ''}`} />
                    <span>{syncingCode === acc.bankCode ? 'Đang đồng bộ...' : 'Kiểm Tra Số Dư'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Sync Logs */}
          {syncLogs.length > 0 && (
            <div className="mt-4 p-3.5 bg-[#121214] text-zinc-300 rounded-2xl text-[11px] font-mono space-y-1 max-h-32 overflow-y-auto border border-zinc-800">
              <div className="font-bold text-zinc-400 uppercase text-[10px] tracking-wider">Nhật ký API Open Banking:</div>
              {syncLogs.slice(0, 5).map((log, idx) => (
                <div key={idx} className="text-emerald-400">
                  {log}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-[#121214] p-4 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-xl transition-colors border border-zinc-700"
          >
            Hoàn Tất
          </button>
        </div>
      </div>
    </div>
  );
};
