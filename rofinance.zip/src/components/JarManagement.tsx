import React, { useState } from 'react';
import {
  Building2,
  Edit2,
  Plus,
  QrCode,
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  Percent,
  Wallet,
  ArrowUpRight,
  ShieldAlert,
  Info,
  CreditCard,
} from 'lucide-react';
import { Jar } from '../types';
import { formatVND } from '../utils/formatters';

interface JarManagementProps {
  jars: Jar[];
  monthlyIncome: number;
  onOpenIncomeModal: () => void;
  onOpenTransactionModal: (defaultJarId?: string) => void;
  onOpenVietQRModal: (jarId: string) => void;
  onUpdateJar: (updatedJar: Jar) => void;
  onOpenDebtModal?: () => void;
  isAmountsHidden?: boolean;
}

export const JarManagement: React.FC<JarManagementProps> = ({
  jars,
  monthlyIncome,
  onOpenIncomeModal,
  onOpenTransactionModal,
  onOpenVietQRModal,
  onUpdateJar,
  onOpenDebtModal,
  isAmountsHidden = false,
}) => {
  const [editingJar, setEditingJar] = useState<Jar | null>(null);

  const totalSpent = jars.reduce((sum, j) => sum + j.currentSpent, 0);
  const totalBudget = jars.reduce((sum, j) => sum + j.targetBudget, 0);
  const totalRemaining = totalBudget - totalSpent;
  const overallUsagePercent = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

  const handleEditSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingJar) {
      onUpdateJar(editingJar);
      setEditingJar(null);
    }
  };

  return (
    <div className="space-y-8">
      {/* Financial Health Summary Bento Card */}
      <div className="bg-[#121214] border border-zinc-800 rounded-[32px] p-6 sm:p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute -right-16 -bottom-16 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 -top-20 w-60 h-60 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs font-bold mb-3">
              <Wallet className="w-3.5 h-3.5" />
              <span>Sức Khỏe Tài Chính Tháng Này</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight font-mono">
              {formatVND(monthlyIncome, isAmountsHidden)} <span className="text-sm font-sans font-normal text-zinc-400">/ thu nhập tháng</span>
            </h2>
            <p className="text-xs text-zinc-400 mt-2 max-w-xl leading-relaxed">
              Phân bổ 6 hũ tài chính tự động theo quy tắc RoFinance chuẩn. Kiểm soát hạn mức chi tiêu thực tế để duy trì cân bằng dòng tiền.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 sm:gap-4">
            <button
              onClick={onOpenIncomeModal}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-2xl shadow-lg shadow-emerald-600/20 transition-all flex items-center space-x-1.5"
            >
              <Wallet className="w-4 h-4" />
              <span>Cập Nhật Thu Nhập</span>
            </button>
            <button
              onClick={() => onOpenTransactionModal()}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-2xl shadow-lg shadow-indigo-600/20 transition-all flex items-center space-x-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Ghi Nhận Chi Tiêu</span>
            </button>
          </div>
        </div>

        {/* Stats Bento Sub-Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8 pt-6 border-t border-zinc-800 relative z-10">
          <div className="bg-[#1c1c20] p-4 rounded-2xl border border-zinc-800/80">
            <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Tổng Hạn Mức</div>
            <div className="text-base sm:text-lg font-black text-white mt-1 font-mono">{formatVND(totalBudget, isAmountsHidden)}</div>
          </div>
          <div className="bg-[#1c1c20] p-4 rounded-2xl border border-zinc-800/80">
            <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Đã Chi Tiêu</div>
            <div
              className={`text-base sm:text-lg font-black mt-1 font-mono ${
                overallUsagePercent > 100 ? 'text-rose-400' : overallUsagePercent >= 80 ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {formatVND(totalSpent, isAmountsHidden)} <span className="text-xs font-sans font-semibold">({overallUsagePercent.toFixed(1)}%)</span>
            </div>
          </div>
          <div className="bg-[#1c1c20] p-4 rounded-2xl border border-zinc-800/80">
            <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Thặng Dư Còn Lại</div>
            <div className={`text-base sm:text-lg font-black mt-1 font-mono ${totalRemaining < 0 ? 'text-rose-400' : 'text-indigo-300'}`}>
              {formatVND(totalRemaining, isAmountsHidden)}
            </div>
          </div>

          <div className="bg-[#1c1c20] p-4 rounded-2xl border border-zinc-800/80">
            <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Trạng Thái An Toàn</div>
            <div className="flex items-center space-x-1.5 mt-1.5">
              {overallUsagePercent > 100 ? (
                <span className="text-xs font-bold text-rose-400 flex items-center space-x-1">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>Vượt Hạn Mức</span>
                </span>
              ) : overallUsagePercent >= 80 ? (
                <span className="text-xs font-bold text-amber-400 flex items-center space-x-1">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Cảnh Báo (&gt;=80%)</span>
                </span>
              ) : (
                <span className="text-xs font-bold text-emerald-400 flex items-center space-x-1">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Cân Bằng Rất Tốt</span>
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 6 Jars Grid Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-lg font-black text-white tracking-tight flex items-center space-x-2">
            <span>Danh Sách 6 Hũ Tài Chính RoFinance</span>
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Mỗi hũ liên kết với tài khoản ngân hàng riêng biệt và có cảnh báo ngưỡng chi tiêu tự động
          </p>
        </div>

        {onOpenDebtModal && (
          <button
            onClick={onOpenDebtModal}
            className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-2xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0"
          >
            <CreditCard className="w-4 h-4 text-rose-400" />
            <span>Tự Tính % Hũ DEBT & Quản Lý Nợ</span>
          </button>
        )}
      </div>

      {/* 6 Jars Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {jars.map((jar) => {
          const usagePercent = jar.targetBudget > 0 ? (jar.currentSpent / jar.targetBudget) * 100 : 0;
          const isDanger = usagePercent > 100;
          const isWarning = usagePercent >= 80 && usagePercent <= 100;
          const remaining = jar.targetBudget - jar.currentSpent;

          return (
            <div
              key={jar.id}
              className={`bg-[#121214] rounded-[28px] p-6 border transition-all duration-200 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-zinc-700 ${
                isDanger
                  ? 'border-rose-500/50 bg-rose-950/10 ring-1 ring-rose-500/30'
                  : isWarning
                  ? 'border-amber-500/50 bg-amber-950/10 ring-1 ring-amber-500/30'
                  : 'border-zinc-800'
              }`}
            >
              {/* Top Bar with Code Badge and Edit button */}
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <span
                      className="w-3.5 h-3.5 rounded-full shrink-0 shadow-sm"
                      style={{ backgroundColor: jar.color }}
                    />
                    <div>
                      <span className="text-[10px] font-black uppercase text-zinc-400 tracking-wider">
                        {jar.code} • {jar.percentage}%
                      </span>
                      <h4 className="text-base font-extrabold text-white mt-0.5">{jar.name}</h4>
                    </div>
                  </div>

                  <button
                    onClick={() => setEditingJar(jar)}
                    className="p-2 text-zinc-500 hover:text-white hover:bg-zinc-800 rounded-xl transition-colors"
                    title="Chỉnh sửa thông số hũ"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Bank Associated */}
                <div className="mt-4 bg-[#1c1c20] p-3 rounded-2xl border border-zinc-800 flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2">
                    <Building2 className="w-4 h-4 text-indigo-400" />
                    <span className="font-bold text-zinc-200">{jar.bankName}</span>
                  </div>
                  <span className="font-mono text-zinc-400 font-semibold">{jar.accountNumber}</span>
                </div>
              </div>

              {/* Progress Bar & Amounts */}
              <div className="my-6 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-zinc-400">Đã chi / Hạn mức:</span>
                  <span className={`font-mono ${isDanger ? 'text-rose-400' : isWarning ? 'text-amber-400' : 'text-zinc-100'}`}>
                    {formatVND(jar.currentSpent, isAmountsHidden)} / {formatVND(jar.targetBudget, isAmountsHidden)}
                  </span>
                </div>

                {/* Progress Bar Container */}
                <div className="w-full h-3 bg-zinc-800/80 rounded-full overflow-hidden p-0.5 border border-zinc-700/50">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isDanger ? 'bg-rose-500' : isWarning ? 'bg-amber-500' : 'bg-indigo-500'
                    }`}
                    style={{ width: `${Math.min(100, usagePercent)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] font-semibold text-zinc-400 pt-0.5">
                  <span className="font-mono">Còn: {formatVND(remaining, isAmountsHidden)}</span>

                  <span
                    className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase border ${
                      isDanger
                        ? 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                        : isWarning
                        ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                        : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                    }`}
                  >
                    {isDanger ? 'Vượt hạn mức' : isWarning ? 'Cảnh báo 80%' : 'An Toàn'}
                  </span>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-3 border-t border-zinc-800/80 flex flex-wrap items-center gap-2">
                <button
                  onClick={() => onOpenTransactionModal(jar.id)}
                  className="flex-1 py-2.5 px-3 bg-[#1c1c20] hover:bg-zinc-800 text-zinc-200 font-bold text-xs rounded-xl transition-all border border-zinc-800 flex items-center justify-center space-x-1.5 min-w-[100px]"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Ghi Chi Tiêu</span>
                </button>
                {jar.code === 'DEBT' && onOpenDebtModal ? (
                  <button
                    onClick={onOpenDebtModal}
                    className="py-2.5 px-3 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-1.5"
                    title="Tự động tính % theo danh sách khoản nợ"
                  >
                    <CreditCard className="w-3.5 h-3.5 text-rose-400" />
                    <span>Tự Tính % DEBT</span>
                  </button>
                ) : null}
                <button
                  onClick={() => onOpenVietQRModal(jar.id)}
                  className="py-2.5 px-3.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-1.5"
                  title="Tạo mã QR chuyển tiền vào hũ"
                >
                  <QrCode className="w-3.5 h-3.5 text-amber-400" />
                  <span>VietQR</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit Jar Modal */}
      {editingJar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="bg-[#18181b] border border-zinc-800 rounded-3xl shadow-2xl max-w-md w-full p-6 space-y-4 text-zinc-100">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-extrabold text-base text-white">
                Cấu Hình Hũ: {editingJar.name} ({editingJar.code})
              </h3>
              <button
                onClick={() => setEditingJar(null)}
                className="text-zinc-400 hover:text-white p-1 rounded-full hover:bg-zinc-800"
              >
                <AlertCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditSave} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-zinc-300 mb-1">Tỷ Lệ Phân Bổ (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={editingJar.percentage}
                  onChange={(e) =>
                    setEditingJar({ ...editingJar, percentage: parseFloat(e.target.value) || 0 })
                  }
                  className="w-full p-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl font-bold text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1">Ngân Hàng Thụ Hưởng</label>
                <input
                  type="text"
                  value={editingJar.bankName}
                  onChange={(e) => setEditingJar({ ...editingJar, bankName: e.target.value })}
                  className="w-full p-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl font-medium text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1">Số Tài Khoản</label>
                <input
                  type="text"
                  value={editingJar.accountNumber}
                  onChange={(e) => setEditingJar({ ...editingJar, accountNumber: e.target.value })}
                  className="w-full p-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl font-mono font-bold text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1">Chủ Tài Khoản</label>
                <input
                  type="text"
                  value={editingJar.accountName}
                  onChange={(e) => setEditingJar({ ...editingJar, accountName: e.target.value })}
                  className="w-full p-2.5 bg-[#1c1c20] border border-zinc-700 rounded-xl font-medium text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setEditingJar(null)}
                  className="px-4 py-2 border border-zinc-700 rounded-xl text-zinc-300 font-bold hover:bg-zinc-800"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition-colors"
                >
                  Lưu Cấu Hình
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
