import { BankCode } from '../types';

export function formatVND(amount: number, hideAmount = false): string {
  if (hideAmount) return '•••••••• ₫';
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatShortVND(amount: number, hideAmount = false): string {
  if (hideAmount) return '•••• ₫';
  if (Math.abs(amount) >= 1_000_000_000) {
    return (amount / 1_000_000_000).toFixed(2).replace(/\.00$/, '') + ' tỷ ₫';
  }
  if (Math.abs(amount) >= 1_000_000) {
    return (amount / 1_000_000).toFixed(2).replace(/\.00$/, '') + ' triệu ₫';
  }
  if (Math.abs(amount) >= 1_000) {
    return (amount / 1_000).toFixed(0) + 'k ₫';
  }
  return amount.toString() + ' ₫';
}

export function formatUSD(amount: number, hideAmount = false): string {
  if (hideAmount) return '•••••••• $';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
  }).format(amount);
}

export function formatDateVI(dateString: string): string {

  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return new Intl.DateTimeFormat('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    }).format(date);
  } catch {
    return dateString;
  }
}

/**
 * Returns a standard VietQR quick transfer QR code URL using standard VietQR OpenAPI format.
 */
export function getVietQRUrl(
  bankCode: BankCode,
  accountNumber: string,
  amount: number,
  addInfo: string,
  accountName: string
): string {
  // Map bank codes to VietQR bin/code
  const bankMap: Record<BankCode, string> = {
    TCB: 'TCB',
    SEAB: 'SEAB',
    MB: 'MB',
    MOMO: 'MOMO',
    VCB: 'VCB',
    VPB: 'VPB',
    ACB: 'ACB',
    BIDV: 'BIDV',
    CTG: 'CTG',
  };

  const code = bankMap[bankCode] || 'VCB';
  const cleanAccount = accountNumber.replace(/[^0-9]/g, '');
  const cleanAmount = Math.max(0, Math.round(amount));
  const encodedInfo = encodeURIComponent(addInfo || 'Phan bo hutaichinh');
  const encodedName = encodeURIComponent(accountName || 'NGUYEN VAN A');

  return `https://img.vietqr.io/image/${code}-${cleanAccount}-compact2.png?amount=${cleanAmount}&addInfo=${encodedInfo}&accountName=${encodedName}`;
}
