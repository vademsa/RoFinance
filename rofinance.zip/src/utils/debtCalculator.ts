import { DebtItem, Jar } from '../types';

/**
 * Calculates number of months between startMonth and endMonth inclusive.
 * e.g. "2026-01" to "2026-12" => 12 months.
 */
export function calculateMonthsCount(startMonth: string, endMonth: string): number {
  if (!startMonth || !endMonth) return 1;
  const [startYear, startM] = startMonth.split('-').map(Number);
  const [endYear, endM] = endMonth.split('-').map(Number);

  if (isNaN(startYear) || isNaN(startM) || isNaN(endYear) || isNaN(endM)) return 1;

  const monthDiff = (endYear - startYear) * 12 + (endM - startM) + 1;
  return Math.max(1, monthDiff);
}

/**
 * Calculate required monthly payment for a debt item.
 */
export function computeMonthlyPayment(
  totalAmount: number,
  startMonth: string,
  endMonth: string
): number {
  const months = calculateMonthsCount(startMonth, endMonth);
  return Math.round(totalAmount / months);
}

/**
 * Check if a debt item has expired based on endMonth or remaining balance.
 */
export function isDebtFullyPaid(debt: DebtItem, currentYYYYMM?: string): boolean {
  if (debt.status === 'paid' || debt.remainingAmount <= 0) return true;
  if (currentYYYYMM && debt.endMonth) {
    if (currentYYYYMM > debt.endMonth) return true;
  }
  return false;
}

/**
 * Recalculate percentage for all 6 Jars based on active debt list and monthly income.
 */
export function recalculateJarsWithDebt(
  currentJars: Jar[],
  debtItems: DebtItem[],
  monthlyIncome: number,
  reallocateStrategy: 'FFA' | 'PROPORTIONAL' = 'PROPORTIONAL'
): Jar[] {
  // Find active debts
  const activeDebts = debtItems.filter((d) => d.status === 'active' && d.remainingAmount > 0);
  const totalMonthlyDebtPayment = activeDebts.reduce((sum, d) => sum + d.monthlyPayment, 0);

  // Calculate new DEBT jar % needed
  let debtPercent = 0;
  if (monthlyIncome > 0) {
    debtPercent = Number(((totalMonthlyDebtPayment / monthlyIncome) * 100).toFixed(2));
  }
  debtPercent = Math.min(100, Math.max(0, debtPercent));

  const remainingPercent = Math.max(0, Number((100 - debtPercent).toFixed(2)));

  // Non-debt jars
  const nonDebtJars = currentJars.filter((j) => j.code !== 'DEBT');
  const debtJar = currentJars.find((j) => j.code === 'DEBT');

  if (reallocateStrategy === 'FFA') {
    // Put excess remaining into FFA, keeping other non-debt jars at standard percentages
    // Standard non-debt percentages: NEC=40, PLAY=10, GIVE=5, EDU=10 (Total 65%)
    // FFA gets whatever is left from (100 - debtPercent - NEC - PLAY - GIVE - EDU)
    const fixedJarsTotal = nonDebtJars
      .filter((j) => j.code !== 'FFA')
      .reduce((sum, j) => sum + j.percentage, 0);
    
    const updatedNonDebt = nonDebtJars.map((jar) => {
      if (jar.code === 'FFA') {
        const ffaPercent = Math.max(0, Number((remainingPercent - fixedJarsTotal).toFixed(2)));
        return {
          ...jar,
          percentage: ffaPercent,
          targetBudget: Math.round((monthlyIncome * ffaPercent) / 100),
        };
      }
      return {
        ...jar,
        targetBudget: Math.round((monthlyIncome * jar.percentage) / 100),
      };
    });

    const updatedDebtJar = debtJar
      ? {
          ...debtJar,
          percentage: debtPercent,
          targetBudget: Math.round((monthlyIncome * debtPercent) / 100),
        }
      : null;

    return updatedDebtJar ? [...updatedNonDebt, updatedDebtJar] : updatedNonDebt;
  }

  // PROPORTIONAL Reallocation:
  // Distribute remainingPercent according to current non-debt jars' relative weights
  const currentNonDebtWeightTotal = nonDebtJars.reduce((sum, j) => sum + (j.percentage || 1), 0);

  const updatedNonDebt = nonDebtJars.map((jar) => {
    let newPercent = 0;
    if (currentNonDebtWeightTotal > 0) {
      newPercent = Number(((jar.percentage / currentNonDebtWeightTotal) * remainingPercent).toFixed(2));
    } else {
      newPercent = Number((remainingPercent / nonDebtJars.length).toFixed(2));
    }

    return {
      ...jar,
      percentage: newPercent,
      targetBudget: Math.round((monthlyIncome * newPercent) / 100),
    };
  });

  const updatedDebtJar = debtJar
    ? {
        ...debtJar,
        percentage: debtPercent,
        targetBudget: Math.round((monthlyIncome * debtPercent) / 100),
      }
    : null;

  return updatedDebtJar ? [...updatedNonDebt, updatedDebtJar] : updatedNonDebt;
}
