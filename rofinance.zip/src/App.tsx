import React, { useState, useEffect, useRef } from 'react';
import { Jar, Transaction, BankAccount, CryptoAsset, DebtItem } from './types';
import {
  DEFAULT_JARS,
  DEFAULT_BANK_ACCOUNTS,
  INITIAL_TRANSACTIONS,
  DEFAULT_MONTHLY_INCOME,
  DEFAULT_CRYPTO_ASSETS,
  DEFAULT_DEBT_ITEMS,
} from './constants/defaultData';
import { Navbar } from './components/Navbar';
import { JarManagement } from './components/JarManagement';
import { TransactionList } from './components/TransactionList';
import { AnalyticsCharts } from './components/AnalyticsCharts';
import { CryptoInvestment } from './components/CryptoInvestment';
import { IncomeAllocatorModal } from './components/IncomeAllocatorModal';
import { VietQRModal } from './components/VietQRModal';
import { TransactionModal } from './components/TransactionModal';
import { BankSyncModal } from './components/BankSyncModal';
import { AIAdvisorDrawer } from './components/AIAdvisorDrawer';
import { BudgetAlertsBanner } from './components/BudgetAlertsBanner';
import { DebtManagementModal } from './components/DebtManagementModal';
import { AuthModal } from './components/AuthModal';
import { exportToExcel, exportToPDFPrint } from './utils/exporter';
import { loadLocalDatabase, saveLocalDatabase } from './lib/localDb';

export default function App() {
  const [userId, setUserId] = useState<string | null>('local_user');
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(true);
  const isInitialLoadRef = useRef<boolean>(true);

  // Initialize state from LocalStorage or defaults
  const [monthlyIncome, setMonthlyIncome] = useState<number>(() => {
    const saved = localStorage.getItem('vf_monthly_income');
    return saved ? Number(saved) : DEFAULT_MONTHLY_INCOME;
  });

  const [jars, setJars] = useState<Jar[]>(() => {
    const saved = localStorage.getItem('vf_jars');
    return saved ? JSON.parse(saved) : DEFAULT_JARS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('vf_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => {
    const saved = localStorage.getItem('vf_bank_accounts');
    return saved ? JSON.parse(saved) : DEFAULT_BANK_ACCOUNTS;
  });

  const [cryptoAssets, setCryptoAssets] = useState<CryptoAsset[]>(() => {
    const saved = localStorage.getItem('vf_crypto_assets');
    return saved ? JSON.parse(saved) : DEFAULT_CRYPTO_ASSETS;
  });

  const [debtItems, setDebtItems] = useState<DebtItem[]>(() => {
    const saved = localStorage.getItem('vf_debt_items');
    return saved ? JSON.parse(saved) : DEFAULT_DEBT_ITEMS;
  });

  const [isAmountsHidden, setIsAmountsHidden] = useState<boolean>(() => {
    const saved = localStorage.getItem('vf_hide_amounts');
    return saved ? JSON.parse(saved) : false;
  });

  const [activeTab, setActiveTab] = useState<'jars' | 'transactions' | 'crypto' | 'analytics'>('jars');

  // Modals state
  const [isIncomeModalOpen, setIsIncomeModalOpen] = useState(false);
  const [isVietQRModalOpen, setIsVietQRModalOpen] = useState(false);
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [isBankSyncModalOpen, setIsBankSyncModalOpen] = useState(false);
  const [isAIAdvisorOpen, setIsAIAdvisorOpen] = useState(false);
  const [isDebtModalOpen, setIsDebtModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Load and initialize from local database
  useEffect(() => {
    async function initLocalData() {
      const data = await loadLocalDatabase();
      if (data) {
        if (data.monthlyIncome !== undefined) setMonthlyIncome(data.monthlyIncome);
        if (data.isAmountsHidden !== undefined) setIsAmountsHidden(data.isAmountsHidden);
        if (data.jars && data.jars.length > 0) setJars(data.jars);
        if (data.transactions) setTransactions(data.transactions);
        if (data.bankAccounts) setBankAccounts(data.bankAccounts);
        if (data.cryptoAssets) setCryptoAssets(data.cryptoAssets);
        if (data.debtItems) setDebtItems(data.debtItems);
      }
      isInitialLoadRef.current = false;
    }
    initLocalData();
  }, []);

  // Save changes to local database instantly
  useEffect(() => {
    if (!isInitialLoadRef.current) {
      saveLocalDatabase({
        monthlyIncome,
        jars,
        transactions,
        bankAccounts,
        cryptoAssets,
        debtItems,
        isAmountsHidden,
      });
    }
  }, [
    monthlyIncome,
    jars,
    transactions,
    bankAccounts,
    cryptoAssets,
    debtItems,
    isAmountsHidden,
  ]);

  // Handlers
  const handleApplyAllocation = (newIncome: number, updatedJars: Jar[]) => {
    setMonthlyIncome(newIncome);
    setJars(updatedJars);
  };

  const handleUpdateJar = (updatedJar: Jar) => {
    setJars((prev) => prev.map((j) => (j.id === updatedJar.id ? updatedJar : j)));
  };

  const handleAddTransaction = (newTxData: Omit<Transaction, 'id'>) => {
    const newTx: Transaction = {
      ...newTxData,
      id: `tx-${Date.now()}`,
    };

    setTransactions((prev) => [newTx, ...prev]);

    // If transaction is an expense, add to Jar's currentSpent
    if (newTx.type === 'expense') {
      setJars((prev) =>
        prev.map((j) =>
          j.id === newTx.jarId
            ? { ...j, currentSpent: j.currentSpent + newTx.amount }
            : j
        )
      );
    }
  };

  const handleDeleteTransaction = (id: string) => {
    const txToDelete = transactions.find((t) => t.id === id);
    if (!txToDelete) return;

    setTransactions((prev) => prev.filter((t) => t.id !== id));

    // Deduct spent if it was an expense
    if (txToDelete.type === 'expense') {
      setJars((prev) =>
        prev.map((j) =>
          j.id === txToDelete.jarId
            ? { ...j, currentSpent: Math.max(0, j.currentSpent - txToDelete.amount) }
            : j
        )
      );
    }
  };

  const handleAddCryptoAsset = (newAssetData: Omit<CryptoAsset, 'id'>) => {
    const newAsset: CryptoAsset = {
      ...newAssetData,
      id: `crypto-${Date.now()}`,
    };
    setCryptoAssets((prev) => [newAsset, ...prev]);
  };

  const handleUpdateCryptoAsset = (updatedAsset: CryptoAsset) => {
    setCryptoAssets((prev) =>
      prev.map((a) => (a.id === updatedAsset.id ? updatedAsset : a))
    );
  };

  const handleDeleteCryptoAsset = (id: string) => {
    setCryptoAssets((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSyncBank = async (bankCode: string) => {
    try {
      const res = await fetch('/api/bank/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bankCode }),
      });
      const data = await res.json();
      if (data.success) {
        setBankAccounts((prev) =>
          prev.map((acc) =>
            acc.bankCode === bankCode
              ? { ...acc, balance: data.newBalance, lastSynced: data.lastSynced }
              : acc
          )
        );
      }
    } catch (err) {
      console.error('Bank sync failed:', err);
    }
  };

  const totalSpent = jars.reduce((sum, j) => sum + j.currentSpent, 0);
  const totalAllocated = jars.reduce((sum, j) => sum + j.targetBudget, 0);

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 font-sans antialiased flex flex-col">
      {/* Header Bar */}
      <Navbar
        monthlyIncome={monthlyIncome}
        totalSpent={totalSpent}
        totalAllocated={totalAllocated}
        onOpenIncomeModal={() => setIsIncomeModalOpen(true)}
        onOpenTransactionModal={() => setIsTransactionModalOpen(true)}
        onOpenBankSyncModal={() => setIsBankSyncModalOpen(true)}
        onOpenAIAdvisor={() => setIsAIAdvisorOpen(true)}
        onExportExcel={() => exportToExcel(jars, transactions, monthlyIncome)}
        onExportPDF={() => exportToPDFPrint(jars, transactions, monthlyIncome)}
        onOpenQRModal={() => setIsVietQRModalOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isAmountsHidden={isAmountsHidden}
        onToggleHideAmounts={() => setIsAmountsHidden((prev) => !prev)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        userEmail={userEmail}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Budget Alerts Banner */}
        <BudgetAlertsBanner
          jars={jars}
          onOpenAIAdvisor={() => setIsAIAdvisorOpen(true)}
          onOpenTransactionModal={(jarId) => setIsTransactionModalOpen(true)}
          isAmountsHidden={isAmountsHidden}
        />

        {/* Tab Contents */}
        {activeTab === 'jars' && (
          <JarManagement
            jars={jars}
            monthlyIncome={monthlyIncome}
            onOpenIncomeModal={() => setIsIncomeModalOpen(true)}
            onOpenTransactionModal={() => setIsTransactionModalOpen(true)}
            onOpenVietQRModal={() => setIsVietQRModalOpen(true)}
            onUpdateJar={handleUpdateJar}
            onOpenDebtModal={() => setIsDebtModalOpen(true)}
            isAmountsHidden={isAmountsHidden}
          />
        )}

        {activeTab === 'transactions' && (
          <TransactionList
            transactions={transactions}
            jars={jars}
            onDeleteTransaction={handleDeleteTransaction}
            onOpenTransactionModal={() => setIsTransactionModalOpen(true)}
            isAmountsHidden={isAmountsHidden}
          />
        )}

        {activeTab === 'crypto' && (
          <CryptoInvestment
            cryptoAssets={cryptoAssets}
            onAddCryptoAsset={handleAddCryptoAsset}
            onUpdateCryptoAsset={handleUpdateCryptoAsset}
            onDeleteCryptoAsset={handleDeleteCryptoAsset}
            isAmountsHidden={isAmountsHidden}
            jars={jars}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsCharts
            jars={jars}
            transactions={transactions}
            monthlyIncome={monthlyIncome}
            isAmountsHidden={isAmountsHidden}
          />
        )}
      </main>

      {/* Modals & Slide-overs */}
      <IncomeAllocatorModal
        isOpen={isIncomeModalOpen}
        onClose={() => setIsIncomeModalOpen(false)}
        jars={jars}
        currentIncome={monthlyIncome}
        onApplyAllocation={handleApplyAllocation}
        onOpenQRWithAllocation={() => setIsVietQRModalOpen(true)}
        onOpenDebtModal={() => setIsDebtModalOpen(true)}
      />

      <DebtManagementModal
        isOpen={isDebtModalOpen}
        onClose={() => setIsDebtModalOpen(false)}
        debtItems={debtItems}
        jars={jars}
        monthlyIncome={monthlyIncome}
        onUpdateDebts={(newDebts) => setDebtItems(newDebts)}
        onApplyNewJarAllocations={(updatedJars) => setJars(updatedJars)}
        isAmountsHidden={isAmountsHidden}
      />

      <VietQRModal
        isOpen={isVietQRModalOpen}
        onClose={() => setIsVietQRModalOpen(false)}
        jars={jars}
        monthlyIncome={monthlyIncome}
      />

      <TransactionModal
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
        jars={jars}
        onAddTransaction={handleAddTransaction}
      />

      <BankSyncModal
        isOpen={isBankSyncModalOpen}
        onClose={() => setIsBankSyncModalOpen(false)}
        bankAccounts={bankAccounts}
        onSyncBank={handleSyncBank}
        isAmountsHidden={isAmountsHidden}
      />

      <AIAdvisorDrawer
        isOpen={isAIAdvisorOpen}
        onClose={() => setIsAIAdvisorOpen(false)}
        jars={jars}
        monthlyIncome={monthlyIncome}
        transactions={transactions}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        userId={userId}
        userEmail={userEmail}
      />

      {/* Simple Footer */}
      <footer className="bg-[#09090b] text-zinc-500 py-6 text-center text-xs border-t border-zinc-800/80 mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© 2026 RoFinance. Quản Lý 6 Hũ Tài Chính & Đầu Tư Tài Sản Số Binance.</p>
          <div className="flex items-center space-x-2 text-[11px] text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Database: Client LocalDB (IndexedDB & LocalStorage) - Hoàn toàn không giới hạn Quota</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

