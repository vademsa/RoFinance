// Local Database Service using IndexedDB & LocalStorage
// Provides zero-quota, ultra-fast, local client database storage.

import { Jar, Transaction, BankAccount, CryptoAsset, DebtItem } from '../types';

export interface LocalAppData {
  monthlyIncome: number;
  jars: Jar[];
  transactions: Transaction[];
  bankAccounts: BankAccount[];
  cryptoAssets: CryptoAsset[];
  debtItems: DebtItem[];
  isAmountsHidden: boolean;
  updatedAt: string;
}

const DB_NAME = 'VietFinanceLocalDB';
const DB_VERSION = 1;
const STORE_NAME = 'app_data';

// Initialize IndexedDB
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Load data from Local Database (IndexedDB with LocalStorage fallback)
export async function loadLocalDatabase(): Promise<Partial<LocalAppData>> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get('user_profile');
      req.onsuccess = () => {
        if (req.result) {
          resolve(req.result);
        } else {
          // Fallback to LocalStorage
          resolve(loadFromLocalStorage());
        }
      };
      req.onerror = () => {
        resolve(loadFromLocalStorage());
      };
    });
  } catch (err) {
    return loadFromLocalStorage();
  }
}

// Save data to Local Database (IndexedDB + LocalStorage)
export async function saveLocalDatabase(data: Partial<LocalAppData>): Promise<void> {
  // Always update LocalStorage synchronously for instant access
  saveToLocalStorage(data);

  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const existing = (await new Promise((resolve) => {
      const req = store.get('user_profile');
      req.onsuccess = () => resolve(req.result || {});
      req.onerror = () => resolve({});
    })) as Partial<LocalAppData>;

    const updatedData: LocalAppData = {
      monthlyIncome: data.monthlyIncome ?? existing.monthlyIncome ?? 0,
      jars: data.jars ?? existing.jars ?? [],
      transactions: data.transactions ?? existing.transactions ?? [],
      bankAccounts: data.bankAccounts ?? existing.bankAccounts ?? [],
      cryptoAssets: data.cryptoAssets ?? existing.cryptoAssets ?? [],
      debtItems: data.debtItems ?? existing.debtItems ?? [],
      isAmountsHidden: data.isAmountsHidden ?? existing.isAmountsHidden ?? false,
      updatedAt: new Date().toISOString(),
    };

    store.put(updatedData, 'user_profile');
  } catch (err) {
    console.warn('IndexedDB write warning, relied on LocalStorage:', err);
  }
}

function loadFromLocalStorage(): Partial<LocalAppData> {
  try {
    const income = localStorage.getItem('vf_monthly_income');
    const jars = localStorage.getItem('vf_jars');
    const transactions = localStorage.getItem('vf_transactions');
    const bankAccounts = localStorage.getItem('vf_bank_accounts');
    const cryptoAssets = localStorage.getItem('vf_crypto_assets');
    const debtItems = localStorage.getItem('vf_debt_items');
    const isAmountsHidden = localStorage.getItem('vf_hide_amounts');

    return {
      monthlyIncome: income ? Number(income) : undefined,
      jars: jars ? JSON.parse(jars) : undefined,
      transactions: transactions ? JSON.parse(transactions) : undefined,
      bankAccounts: bankAccounts ? JSON.parse(bankAccounts) : undefined,
      cryptoAssets: cryptoAssets ? JSON.parse(cryptoAssets) : undefined,
      debtItems: debtItems ? JSON.parse(debtItems) : undefined,
      isAmountsHidden: isAmountsHidden ? JSON.parse(isAmountsHidden) : undefined,
    };
  } catch (err) {
    return {};
  }
}

function saveToLocalStorage(data: Partial<LocalAppData>): void {
  try {
    if (data.monthlyIncome !== undefined) localStorage.setItem('vf_monthly_income', data.monthlyIncome.toString());
    if (data.jars !== undefined) localStorage.setItem('vf_jars', JSON.stringify(data.jars));
    if (data.transactions !== undefined) localStorage.setItem('vf_transactions', JSON.stringify(data.transactions));
    if (data.bankAccounts !== undefined) localStorage.setItem('vf_bank_accounts', JSON.stringify(data.bankAccounts));
    if (data.cryptoAssets !== undefined) localStorage.setItem('vf_crypto_assets', JSON.stringify(data.cryptoAssets));
    if (data.debtItems !== undefined) localStorage.setItem('vf_debt_items', JSON.stringify(data.debtItems));
    if (data.isAmountsHidden !== undefined) localStorage.setItem('vf_hide_amounts', JSON.stringify(data.isAmountsHidden));
  } catch (err) {
    console.error('LocalStorage write error:', err);
  }
}

// Export Database to JSON File
export function exportDatabaseBackup(data: LocalAppData) {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `vietfinance_backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}
