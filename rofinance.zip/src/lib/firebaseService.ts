import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';
import { Jar, Transaction, BankAccount, CryptoAsset, DebtItem } from '../types';

export interface UserData {
  monthlyIncome?: number;
  isAmountsHidden?: boolean;
  jars?: Jar[];
  transactions?: Transaction[];
  bankAccounts?: BankAccount[];
  cryptoAssets?: CryptoAsset[];
  debtItems?: DebtItem[];
  updatedAt?: string;
}

let isQuotaExceeded = false;

export function getIsQuotaExceeded() {
  return isQuotaExceeded;
}

export function subscribeToUserData(
  userId: string,
  onData: (data: UserData) => void,
  onError?: (err: Error) => void
) {
  if (isQuotaExceeded) {
    onData({});
    return () => {};
  }

  const userDocRef = doc(db, 'users', userId);
  let unsubscribe: () => void = () => {};

  unsubscribe = onSnapshot(
    userDocRef,
    (snapshot) => {
      if (snapshot.exists()) {
        onData(snapshot.data() as UserData);
      } else {
        onData({});
      }
    },
    (error: any) => {
      if (
        error?.code === 'resource-exhausted' ||
        error?.message?.includes('Quota limit exceeded') ||
        error?.toString()?.includes('Quota limit exceeded')
      ) {
        isQuotaExceeded = true;
        console.warn('Firestore quota limit reached. App seamlessly operating in local storage mode.');
        try {
          if (unsubscribe) unsubscribe();
        } catch (_) {}
        onData({});
      } else {
        console.error('Error listening to user data from Firestore:', error);
      }
      if (onError) onError(error);
    }
  );

  return unsubscribe;
}

export async function saveUserDataToFirestore(userId: string, data: Partial<UserData>) {
  if (isQuotaExceeded) return; // Skip Firestore writes if daily free tier quota is exhausted

  try {
    const userDocRef = doc(db, 'users', userId);
    await setDoc(
      userDocRef,
      {
        ...data,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error: any) {
    if (
      error?.code === 'resource-exhausted' ||
      error?.message?.includes('Quota limit exceeded') ||
      error?.toString()?.includes('Quota limit exceeded')
    ) {
      isQuotaExceeded = true;
      console.warn('Firestore write quota exceeded. App seamlessly using local storage.');
    } else {
      console.error('Error saving user data to Firestore:', error);
    }
  }
}
